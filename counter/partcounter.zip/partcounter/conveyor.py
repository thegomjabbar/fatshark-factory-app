"""Conveyor mode: follow each part across frames and count it once when its
centre crosses the count line. Works with the same part profiles and flags as
the light-board mode (touching parts count as their estimate and are flagged;
wrong-shape and too-small items are flagged and not counted)."""
import collections
import time

import cv2

import vision

DIRS = ("lr", "rl", "tb", "bt")   # belt travel: left->right, right->left, top->bottom, bottom->top


class Tracker:
    def __init__(self):
        self.reset_all()

    def reset_all(self):
        self.tracks = []
        self.next_id = 1
        self.count = 0              # parts counted since the last log/reset
        self.flags = collections.Counter()
        self.run_total = 0          # parts counted since conveyor mode started (or full reset)
        self.events = collections.deque(maxlen=12)
        self.last_event = 0.0

    def reset_count(self):
        self.count = 0
        self.flags = collections.Counter()

    @staticmethod
    def _along(d, x, y, roi):
        x0, y0, w, h = roi
        return {"lr": x - x0, "rl": x0 + w - x, "tb": y - y0, "bt": y0 + h - y}[d]

    def update(self, blobs, roi, settings):
        """Match this frame's blobs to tracks; return a list of crossing events."""
        d = settings.get("conv_dir", "lr")
        if d not in DIRS:
            d = "lr"
        x0, y0, w, h = roi
        length = w if d in ("lr", "rl") else h
        line = float(settings.get("conv_line", 0.5)) * length
        max_jump = max(25.0, float(settings.get("conv_max_jump", 0.18)) * length)
        dets = []
        for b in blobs:
            if b["kind"] in ("debris", "ignored"):
                continue
            cx, cy = vision.blob_center(b)
            dets.append({"x": cx, "y": cy, "u": self._along(d, cx, cy, roi), "b": b})
        used = set()
        events = []
        # oldest tracks first; each takes the nearest detection ahead of where it was predicted
        for t in sorted(self.tracks, key=lambda t: -t["u"]):
            pu = t["u"] + t["v"]
            best, bd = None, None
            for i, det in enumerate(dets):
                if i in used or det["u"] < t["u"] - 0.03 * length:
                    continue
                dist = ((det["x"] - (t["x"] + t["vx"])) ** 2 + (det["y"] - (t["y"] + t["vy"])) ** 2) ** 0.5
                if dist <= max_jump and (bd is None or dist < bd):
                    best, bd = i, dist
            if best is None:
                t["missed"] += 1
                continue
            used.add(best)
            det = dets[best]
            prev_u = t["u"]
            t["vx"], t["vy"] = 0.6 * t["vx"] + 0.4 * (det["x"] - t["x"]), 0.6 * t["vy"] + 0.4 * (det["y"] - t["y"])
            t["v"] = 0.6 * t["v"] + 0.4 * (det["u"] - prev_u)
            t.update(x=det["x"], y=det["y"], u=det["u"], missed=0, kind=det["b"]["kind"], est=det["b"]["est"])
            if not t["counted"] and prev_u < line <= det["u"]:
                t["counted"] = True
                events.append(self._count(t))
            _ = pu
        for i, det in enumerate(dets):
            if i in used:
                continue
            self.tracks.append({"id": self.next_id, "x": det["x"], "y": det["y"], "u": det["u"], "v": 0.0,
                                "vx": 0.0, "vy": 0.0, "missed": 0, "kind": det["b"]["kind"], "est": det["b"]["est"],
                                # something that first shows up past the line was not seen crossing it
                                "counted": det["u"] >= line})
            self.next_id += 1
        self.tracks = [t for t in self.tracks if t["missed"] <= 3]
        return events

    def _count(self, t):
        k = t["kind"]
        n = int(t["est"]) if k in ("single", "clump", "confirmed") else 0
        if k == "single":
            n = 1
        self.count += n
        self.run_total += n
        if k in ("clump", "foreign", "partial", "edge"):
            self.flags[k] += 1
        ev = {"time": time.strftime("%H:%M:%S"), "kind": k, "n": n, "id": t["id"]}
        self.events.appendleft(ev)
        self.last_event = time.time()
        return ev

    def draw(self, img, scale, roi, settings):
        d = settings.get("conv_dir", "lr")
        x0, y0, w, h = [v * scale for v in roi]
        pos = float(settings.get("conv_line", 0.5))
        col = vision.COLORS["accent"]
        if d in ("lr", "rl"):
            lx = x0 + (pos if d == "lr" else 1 - pos) * w
            cv2.line(img, (int(lx), int(y0)), (int(lx), int(y0 + h)), col, 3, cv2.LINE_AA)
            a = (int(lx - 40), int(y0 + 24)) if d == "lr" else (int(lx + 40), int(y0 + 24))
            cv2.arrowedLine(img, a, (int(lx), int(y0 + 24)), col, 3, cv2.LINE_AA, tipLength=0.4)
        else:
            ly = y0 + (pos if d == "tb" else 1 - pos) * h
            cv2.line(img, (int(x0), int(ly)), (int(x0 + w), int(ly)), col, 3, cv2.LINE_AA)
            a = (int(x0 + 24), int(ly - 40)) if d == "tb" else (int(x0 + 24), int(ly + 40))
            cv2.arrowedLine(img, a, (int(x0 + 24), int(ly)), col, 3, cv2.LINE_AA, tipLength=0.4)
        for t in self.tracks:
            if t["counted"] and t["missed"] == 0:
                cv2.circle(img, (int(t["x"] * scale), int(t["y"] * scale)), 6, vision.COLORS["single"], -1, cv2.LINE_AA)
        return img
