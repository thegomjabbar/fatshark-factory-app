"""Backlit part detection, multi-view part profiles and counting.

The light board turns every part into a dark silhouette on a bright field.
A part profile holds one or more *views*: each way the part can land on the
board (flat, flipped, on its side...). Each view stores a typical silhouette
area plus a few reference outlines. Every blob is compared against all views:

  single   - matches a view's size and shape          -> counts 1
  clump    - bigger than any view (touching/stacked)   -> estimated N, flagged
  partial  - smaller than any view                     -> flagged
  foreign  - doesn't match any view's shape            -> flagged
  edge     - cut off by the count-area edge            -> flagged
  ignored  - matches something taught as "not a part"  -> ignored
  debris   - tiny specks                               -> ignored
"""
import time

import cv2
import numpy as np

SEG_KEYS = ("threshold_mode", "threshold", "dark_parts", "blur", "morph", "min_area_px")

DEFAULT_SETTINGS = {
    "threshold_mode": "fixed",   # fixed | otsu
    "threshold": 110,
    "dark_parts": True,
    "blur": 2,
    "morph": 1,
    "min_area_px": 30,
    "single_tol": 0.30,
    "shape_check": True,
    "ignore_edge": True,
    "roi": None,                 # [x, y, w, h] normalized
    "target": 0,
    "stream_width": 1280,
    "auto_capture": "lock",      # off | lock | target
    "capture_hold": 1.5,         # seconds the count must stay locked before auto capture
    "clear_hold": 1.0,           # seconds the board must stay empty to re-arm
    "require_signin": True,      # operators must sign in before counting (when operators exist)
    "auto_print": False,         # print a bag label for every good kit
    "label_w": 2.0,              # label size, inches
    "label_h": 1.0,
    "station_mode": "board",     # board (piles on a light board) | conveyor (parts moving past a line)
    "conv_dir": "lr",            # belt travel: lr, rl, tb, bt
    "conv_line": 0.5,            # count line position along the travel direction (0-1)
    "conv_max_jump": 0.18,       # furthest a part may move between frames (fraction of the view)
    "auto_accept": 75,           # touching groups at or above this confidence (%) are counted without asking
    "show_conf": True,           # print the confidence next to each part on the live view
}

# UI hex colours; drawn on frames as BGR
HEX = {
    "group": "#4ade80",
    "single": "#4ade80", "clump": "#fbbf24", "partial": "#f472b6", "foreign": "#f87171",
    "edge": "#60a5fa", "debris": "#6b6b7b", "ignored": "#6b6b7b", "raw": "#b9a7ff",
    "skip": "#8a8aa0", "accent": "#b9a7ff", "confirmed": "#4ade80",
}
VIEW_COLORS = ["#b9a7ff", "#5eead4", "#fbbf24", "#f472b6", "#60a5fa", "#a3e635", "#fb923c", "#e879f9",
               "#38bdf8", "#facc15"]
FONT = cv2.FONT_HERSHEY_SIMPLEX


def bgr(hexstr):
    h = hexstr.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (b, g, r)


COLORS = {k: bgr(v) for k, v in HEX.items()}


# ----------------------------------------------------------------- geometry
def roi_pixels(roi, W, H):
    if not roi:
        return 0, 0, W, H
    x, y, w, h = roi
    x0 = int(max(0.0, min(1.0, x)) * W)
    y0 = int(max(0.0, min(1.0, y)) * H)
    x1 = int(max(0.0, min(1.0, x + w)) * W)
    y1 = int(max(0.0, min(1.0, y + h)) * H)
    if x1 - x0 < 16 or y1 - y0 < 16:
        return 0, 0, W, H
    return x0, y0, x1 - x0, y1 - y0


def fit_width(img, out_w, interp=cv2.INTER_AREA):
    H, W = img.shape[:2]
    if W <= out_w:
        return img.copy(), 1.0
    s = out_w / W
    return cv2.resize(img, (out_w, int(round(H * s))), interpolation=interp), s


def mirror(c):
    m = c.copy()
    m[:, :, 0] = -m[:, :, 0]
    return m


def normalize_contour(c):
    c = c.reshape(-1, 1, 2).astype(np.int32)
    return c - c.reshape(-1, 2).min(axis=0)


def to_contour(lst):
    return np.array(lst, np.int32).reshape(-1, 1, 2)


def contour_feat(c, hole_area=0.0):
    """Cheap silhouette features: elongation, solidity, hole fraction."""
    area = float(cv2.contourArea(c)) or 1.0
    (_, (w, h), _) = cv2.minAreaRect(c)
    aspect = max(w, h) / max(1.0, min(w, h))
    hull = float(cv2.contourArea(cv2.convexHull(c))) or area
    return [round(aspect, 4), round(area / hull, 4), round(min(1.0, hole_area / area), 4)]


def feat_dist(fa, fb):
    return (abs(np.log(max(fa[0], 1e-3) / max(fb[0], 1e-3)))
            + 2.0 * abs(fa[1] - fb[1]) + 2.0 * abs(fa[2] - fb[2]))


def hu_sig(c):
    """Log-scaled Hu moments of an outline (computed once, reused for matching)."""
    h = cv2.HuMoments(cv2.moments(c)).flatten()
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(np.abs(h) > 1e-5, np.sign(h) * np.log10(np.abs(h)), 0.0)   # tiny moments ignored, as OpenCV does


def _i3(a, b):
    m = (a != 0) & (b != 0)
    return float(np.max(np.abs(a[m] - b[m]) / np.abs(a[m]))) if m.any() else 0.0


def shape_dist(sigs, rfeats, sig, f):
    """How different an outline is from the closest reference (0 = identical).
    Hu moments (mirror-aware, so a part lying upside down still matches) plus
    elongation, solidity and hole size."""
    best = 9.0
    sig_m = sig.copy()
    sig_m[6] = -sig_m[6]            # the 7th Hu moment flips sign in a mirror image
    for rs, rf in zip(sigs, rfeats):
        best = min(best, min(_i3(rs, sig), _i3(rs, sig_m)) + feat_dist(rf, f))
    return float(best)


def blob_at(blobs, x, y, max_dist):
    """Blob containing pixel (x, y), else the nearest one within max_dist."""
    best, bd = None, None
    for i, b in enumerate(blobs):
        d = cv2.pointPolygonTest(b["c"], (float(x), float(y)), True)
        if d >= 0:
            return i
        if -d <= max_dist and (bd is None or -d < bd):
            best, bd = i, -d
    return best


def blobs_in_rect(blobs, x0, y0, x1, y1):
    out = []
    for i, b in enumerate(blobs):
        m = cv2.moments(b["c"])
        if m["m00"] <= 0:
            continue
        cx, cy = m["m10"] / m["m00"], m["m01"] / m["m00"]
        if x0 <= cx <= x1 and y0 <= cy <= y1:
            out.append(i)
    return out


# ------------------------------------------------------------- segmentation
def segment(gray, s):
    r = int(s.get("blur", 2))
    g = cv2.GaussianBlur(gray, (2 * r + 1, 2 * r + 1), 0) if r > 0 else gray
    flag = cv2.THRESH_BINARY_INV if s.get("dark_parts", True) else cv2.THRESH_BINARY
    if s.get("threshold_mode") == "otsu":
        t, mask = cv2.threshold(g, 0, 255, flag | cv2.THRESH_OTSU)
        if float(g[::4, ::4].std()) < 6.0:
            mask[:] = 0
    else:
        t, mask = cv2.threshold(g, int(s.get("threshold", 110)), 255, flag)
    m = int(s.get("morph", 1))
    if m > 0:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * m + 1, 2 * m + 1))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k)
    return mask, float(t)


def find_blobs(mask, s, offset=(0, 0)):
    H, W = mask.shape
    ox, oy = offset
    cnts, hier = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    blobs = []
    if hier is None:
        return blobs
    hier = hier[0]
    min_a = float(s.get("min_area_px", 30))
    for i, c in enumerate(cnts):
        if hier[i][3] != -1:          # a hole, not an outer outline
            continue
        area = float(cv2.contourArea(c))
        if area < min_a:
            continue
        hole, j = 0.0, hier[i][2]
        while j != -1:
            hole += float(cv2.contourArea(cnts[j]))
            j = hier[j][0]
        x, y, w, h = cv2.boundingRect(c)
        edge = x <= 1 or y <= 1 or x + w >= W - 1 or y + h >= H - 1
        feat = contour_feat(c, hole)
        sig = hu_sig(c)
        c = c + np.array([[[ox, oy]]], dtype=c.dtype)
        blobs.append({"c": c, "area": area, "feat": feat, "sig": sig, "bbox": (x + ox, y + oy, w, h), "edge": edge,
                      "kind": "raw", "est": 1, "ratio": None, "view": None})
    return blobs


# ----------------------------------------------------------------- profiles
def view_stats(areas, samples, base_refs=(), base_feats=(), max_refs=6):
    """Build a view's numbers from sample areas and (contour, feat) samples."""
    areas = [float(a) for a in areas][-800:]
    unit = float(np.median(areas))
    spread = float(np.median(np.abs(np.array(areas) - unit)) / unit) if unit else 0.0
    refs = [to_contour(r) for r in base_refs][:max_refs]
    feats = [list(f) for f in base_feats][:len(refs)]
    while len(feats) < len(refs):
        feats.append(contour_feat(refs[len(feats)]))
    if len(refs) < max_refs and samples:
        order = sorted(samples, key=lambda cf: abs(cv2.contourArea(cf[0]) - unit))
        for c, f in order[: max_refs - len(refs)]:
            refs.append(normalize_contour(c))
            feats.append(list(f))
    sigs = [hu_sig(r) for r in refs]
    scores = []
    for i in range(len(refs)):          # spread among the references themselves
        if len(refs) > 1:
            o = [j for j in range(len(refs)) if j != i]
            scores.append(shape_dist([sigs[j] for j in o], [feats[j] for j in o], sigs[i], feats[i]))
    for c, f in samples:
        sc = shape_dist(sigs, feats, hu_sig(c), f)
        if sc > 1e-6:
            scores.append(sc)
    scores = scores or [0.1]
    thresh = min(1.5, max(0.3, float(np.percentile(scores, 95)) * 2.5))
    return {"unit_area": unit, "spread": spread, "samples": areas,
            "refs": [r.reshape(-1, 2).tolist() for r in refs], "ref_feats": feats, "shape_thresh": thresh}


def migrate_profile(p):
    """Old single-view profiles -> multi-view."""
    if "views" not in p:
        p["views"] = [{
            "id": "v1", "tag": "A", "name": "Flat", "color": VIEW_COLORS[0],
            "unit_area": p.get("unit_area", 1.0), "spread": p.get("spread", 0.0),
            "samples": p.get("samples", []), "refs": [p["ref"]] if p.get("ref") else [],
            "shape_thresh": 0.4}]
        for k in ("unit_area", "spread", "samples", "ref", "shape_thresh", "n_samples"):
            p.pop(k, None)
    for v in p["views"]:
        if len(v.get("ref_feats", [])) != len(v.get("refs", [])):
            v["ref_feats"] = [contour_feat(to_contour(r)) for r in v.get("refs", [])]
            v["shape_thresh"] = max(0.4, float(v.get("shape_thresh", 0.4)))
    p.setdefault("ignores", [])
    for g in p["ignores"]:
        g.setdefault("feat", contour_feat(to_contour(g["ref"])))
    return p


def count_peaks(c, r1):
    """Number of round 'cores' in an outline: touching round parts give one peak each."""
    x, y, w, h = cv2.boundingRect(c)
    if w * h > 4_000_000 or r1 <= 1:
        return 0
    m = np.zeros((h + 4, w + 4), np.uint8)
    cv2.drawContours(m, [c - np.array([[[x - 2, y - 2]]], dtype=c.dtype)], -1, 255, -1)
    d = cv2.distanceTransform(m, cv2.DIST_L2, 5)
    k = max(3, int(r1 * 0.9) | 1)
    dil = cv2.dilate(d, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    peaks = ((d >= dil - 1e-3) & (d >= 0.6 * r1)).astype(np.uint8)
    n, _ = cv2.connectedComponents(peaks)
    return n - 1


def core_radius(c):
    x, y, w, h = cv2.boundingRect(c)
    m = np.zeros((h + 4, w + 4), np.uint8)
    cv2.drawContours(m, [c - np.array([[[x - 2, y - 2]]], dtype=c.dtype)], -1, 255, -1)
    return float(cv2.distanceTransform(m, cv2.DIST_L2, 5).max())


def compile_profile(p):
    views = []
    for v in p.get("views", []):
        if not v.get("samples"):
            continue
        refs = [to_contour(r) for r in v.get("refs", [])]
        views.append({"id": v["id"], "name": v["name"], "tag": v.get("tag", "?"),
                      "unit": float(v["unit_area"]), "spread": float(v.get("spread", 0)),
                      "thresh": float(v.get("shape_thresh", 0.4)), "n": len(v["samples"]),
                      "sigs": [hu_sig(r) for r in refs], "feats": v.get("ref_feats", []), "refs": refs})
    if not views:
        return None
    ign = []
    for g in p.get("ignores", []):
        r = to_contour(g["ref"])
        ign.append({"area": float(g["area"]), "sigs": [hu_sig(r)], "feats": [g["feat"]]})
    common = max(views, key=lambda v: v["n"])
    # can touching parts be split by counting round cores? only if each single has exactly one
    r1, peaks_ok = 0.0, False
    if common["refs"]:
        r1 = float(np.median([core_radius(r) for r in common["refs"]]))
        peaks_ok = all(count_peaks(r, r1) == 1 for r in common["refs"])
    learned = [float(x) for x in p.get("clump_samples", []) if x]
    clump_unit = float(np.median(learned)) if len(learned) >= 3 else common["unit"]
    return {"name": p["name"], "views": views, "ignores": ign,
            "clump_unit": clump_unit, "r1": r1, "peaks_ok": peaks_ok, "learned_groups": len(learned),
            "min_unit": min(v["unit"] for v in views),
            "max_unit": max(v["unit"] for v in views)}


# ----------------------------------------------------------- classification
def classify(blobs, cp, s):
    base_tol = float(s.get("single_tol", 0.3))
    shape_on = bool(s.get("shape_check", True))
    for b in blobs:
        a = b["area"]
        b["view"] = None
        ignored = False
        for g in cp["ignores"]:
            if abs(a / g["area"] - 1) <= 0.25 and (a < 300 or
                    shape_dist(g["sigs"], g["feats"], b["sig"], b["feat"]) <= 0.4):
                ignored = True
                break
        if ignored:
            b["kind"], b["est"] = "ignored", 0
            continue
        if a < 0.25 * cp["min_unit"]:
            b["kind"], b["est"] = "debris", 0
            continue
        if b["edge"] and s.get("ignore_edge", True):
            # something huge at the edge is the board frame or glare, not a part
            b["kind"], b["est"] = ("ignored", 0) if a > 4 * cp["max_unit"] else ("edge", 0)
            continue
        best, size_fit, lo_min, hi_max = None, False, 9e9, 0
        for v in cp["views"]:
            tol = max(base_tol, 3.0 * v["spread"])
            lo, hi = max(0.5, 1 - tol), 1 + tol
            lo_min, hi_max = min(lo_min, lo * v["unit"]), max(hi_max, hi * v["unit"])
            r = a / v["unit"]
            if not lo <= r <= hi:
                continue
            size_fit = True
            if shape_on and v["unit"] >= 300 and v["sigs"]:
                if shape_dist(v["sigs"], v["feats"], b["sig"], b["feat"]) > v["thresh"]:
                    continue
            d = abs(r - 1)
            sd = (shape_dist(v["sigs"], v["feats"], b["sig"], b["feat"]) / v["thresh"]) if (shape_on and v["unit"] >= 300 and v["sigs"]) else 0.0
            conf = 100.0 * (1.0 - 0.5 * min(1.0, max(d / tol, sd)))
            if best is None or d < best[0]:
                best = (d, v, conf)
        b["conf"] = None
        if best:
            b["kind"], b["est"], b["view"], b["conf"] = "single", 1, best[1]["name"], round(best[2])
        elif a < lo_min:
            b["kind"], b["est"] = "partial", 0
        elif a > hi_max:
            est, conf = group_estimate(b, cp)
            b["est"], b["conf"] = est, conf
            b["kind"] = "group" if conf >= float(s.get("auto_accept", 75)) else "clump"
        else:
            b["kind"], b["est"] = "foreign", 0
        b["ratio"] = a / cp["clump_unit"]


def group_estimate(b, cp):
    """How many parts are in a touching group, and how sure we are (0-100)."""
    n_area = b["area"] / cp["clump_unit"]
    n = max(2, int(round(n_area)))
    frac = abs(n_area - round(n_area))                  # 0 = right on a whole number
    size_conf = max(0.0, 1.0 - 2.5 * frac)              # 0.4 off a whole number -> 0
    if cp.get("peaks_ok") and cp.get("r1"):
        p = count_peaks(b["c"], cp["r1"])
        if p == n:
            conf = 0.55 + 0.45 * size_conf               # two independent methods agree
        elif p >= 2 and abs(p - n_area) < abs(n - n_area) + 0.35:
            n, conf = p, 0.45 + 0.3 * max(0.0, 1.0 - 2.5 * abs(n_area - p))
        else:
            conf = 0.5 * size_conf
    else:
        conf = 0.25 + 0.65 * size_conf
    return n, int(round(100 * conf))


def _pl(n, one, many=None):
    return one if n == 1 else (many or one + "s")


def summarize(blobs, cp):
    kinds = ("single", "group", "clump", "partial", "foreign", "edge", "debris", "ignored", "raw", "confirmed")
    n = {k: 0 for k in kinds}
    clump_parts = operator_parts = group_parts = 0
    per_view = {}
    for b in blobs:
        n[b["kind"]] += 1
        if b["kind"] == "clump":
            clump_parts += b["est"]
        if b["kind"] == "confirmed":
            operator_parts += b["est"]
        if b["kind"] == "group":
            group_parts += b["est"]
        if b["kind"] == "single":
            per_view[b["view"]] = per_view.get(b["view"], 0) + 1
    attention = []
    if cp:
        confirmed = n["single"] + group_parts + operator_parts
        estimated = confirmed + clump_parts
        name = cp["name"]
        if n["clump"]:
            attention.append({"kind": "clump", "text":
                f"{n['clump']} {_pl(n['clump'], 'group')} the counter isn't sure about (about "
                f"{clump_parts} parts). Nudge {'it' if n['clump'] == 1 else 'them'} apart, or tap to say how many. It learns from your answer."})
        if n["foreign"]:
            attention.append({"kind": "foreign", "text":
                f"{n['foreign']} {_pl(n['foreign'], 'item')} {'does' if n['foreign'] == 1 else 'do'} not "
                f"match {name}. Remove {'it' if n['foreign'] == 1 else 'them'}, or tap "
                f"{'it' if n['foreign'] == 1 else 'one'} to teach a new view."})
        if n["partial"]:
            attention.append({"kind": "partial", "text":
                f"{n['partial']} {_pl(n['partial'], 'item')} smaller than any {name} view. Check the "
                "pink outlines for broken parts, or tap one to teach it as a view."})
        if n["edge"]:
            attention.append({"kind": "edge", "text":
                f"{n['edge']} {_pl(n['edge'], 'item')} cut off at the edge of the count area. "
                f"Move {'it' if n['edge'] == 1 else 'them'} inward."})
    else:
        confirmed = estimated = n["raw"]
    return {
        "mode": "profile" if cp else "raw",
        "confirmed": confirmed, "estimated": estimated, "clump_parts": clump_parts,
        "operator_parts": operator_parts, "operator_groups": n["confirmed"],
        "group_parts": group_parts,
        "counts": n, "per_view": per_view, "attention": attention,
        "attention_count": n["clump"] + n["foreign"] + n["partial"] if cp else 0,
        "blob_count": len(blobs),
    }


def blob_center(b):
    m = cv2.moments(b["c"])
    if m["m00"] <= 0:
        x, y, w, h = b["bbox"]
        return x + w / 2, y + h / 2
    return m["m10"] / m["m00"], m["m01"] / m["m00"]


def match_confirm(b, confirms):
    """An operator-confirmed group that this blob still is (same place, same size)."""
    cx, cy = blob_center(b)
    tol = max(15.0, 0.5 * b["area"] ** 0.5)
    for i, cf in enumerate(confirms):
        if abs(b["area"] / cf["area"] - 1) <= 0.15 and ((cx - cf["x"]) ** 2 + (cy - cf["y"]) ** 2) ** 0.5 <= tol:
            return i
    return None


def apply_confirms(blobs, confirms):
    for b in blobs:
        if b["kind"] in ("clump", "foreign", "partial"):
            i = match_confirm(b, confirms)
            if i is not None:
                b["kind"], b["est"] = "confirmed", int(confirms[i]["n"])


def process(frame, s, cp, confirms=None):
    H, W = frame.shape[:2]
    x, y, w, h = roi_pixels(s.get("roi"), W, H)
    crop = frame[y:y + h, x:x + w]
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop
    mask, t = segment(gray, s)
    blobs = find_blobs(mask, s, (x, y))
    if cp:
        classify(blobs, cp, s)
        if confirms:
            apply_confirms(blobs, confirms)
    summary = summarize(blobs, cp)
    summary["threshold_used"] = round(t, 1)
    summary["board_level"] = round(float(np.percentile(gray[::8, ::8], 90)), 1)
    summary["frame_size"] = [W, H]
    full_mask = np.zeros((H, W), np.uint8)
    full_mask[y:y + h, x:x + w] = mask
    return blobs, summary, full_mask, (x, y, w, h)


# --------------------------------------------------------------- annotation
def brackets(img, x, y, w, h, col, t=2):
    L = max(6, min(w, h) // 3)
    for px, py, dx, dy in ((x, y, 1, 1), (x + w, y, -1, 1), (x, y + h, 1, -1), (x + w, y + h, -1, -1)):
        cv2.line(img, (px, py), (px + dx * L, py), col, t, cv2.LINE_AA)
        cv2.line(img, (px, py), (px, py + dy * L), col, t, cv2.LINE_AA)


def label(img, text, x, y, col, scale=0.6):
    (tw, th), _ = cv2.getTextSize(text, FONT, scale, 2)
    x = max(0, x)
    y = max(th + 6, y)
    cv2.rectangle(img, (x, y - th - 6), (x + tw + 8, y + 3), (23, 14, 18), -1)
    cv2.putText(img, text, (x + 4, y - 3), FONT, scale, col, 2, cv2.LINE_AA)


def annotate(small, scale, blobs, roi_px, show_conf=True):
    img = small.copy()
    for b in blobs:
        c = np.round(b["c"].astype(np.float32) * scale).astype(np.int32)
        k = b["kind"]
        col = COLORS.get(k, COLORS["raw"])
        cv2.drawContours(img, [c], -1, col, 1 if k in ("debris", "ignored") else 2, cv2.LINE_AA)
        if k in ("clump", "foreign", "partial", "edge", "confirmed", "group"):
            x, y, w, h = cv2.boundingRect(c)
            p = 6
            brackets(img, x - p, y - p, w + 2 * p, h + 2 * p, col)
            conf = f" {b['conf']}%" if (show_conf and b.get("conf") is not None) else ""
            text = {"clump": f"x{b['est']}?{conf}", "foreign": "?", "partial": "!", "edge": "edge",
                    "confirmed": f"x{b['est']} ok", "group": f"x{b['est']}{conf}"}[k]
            label(img, text, x - p, y - p - 4, col)
        elif k == "single" and show_conf and b.get("conf") is not None:
            x, y, w, h = cv2.boundingRect(c)
            cv2.putText(img, f"{b['conf']}", (x + w + 2, y + 10), FONT, 0.38, (60, 120, 60), 1, cv2.LINE_AA)
    x, y, w, h = [int(round(v * scale)) for v in roi_px]
    H, W = img.shape[:2]
    if (w, h) != (W, H):
        brackets(img, x, y, w - 1, h - 1, COLORS["accent"], 2)
    return img


def outline_view(small, scale, blobs, roi_px):
    """Every detected blob in one colour; used while teaching."""
    img = small.copy()
    for b in blobs:
        c = np.round(b["c"].astype(np.float32) * scale).astype(np.int32)
        cv2.drawContours(img, [c], -1, COLORS["edge"] if b["edge"] else COLORS["accent"], 2, cv2.LINE_AA)
    x, y, w, h = [int(round(v * scale)) for v in roi_px]
    H, W = img.shape[:2]
    if (w, h) != (W, H):
        brackets(img, x, y, w - 1, h - 1, COLORS["accent"], 2)
    return img


def mask_view(mask, roi_px, out_w):
    small, s = fit_width(mask, out_w, cv2.INTER_NEAREST)
    img = cv2.cvtColor(small, cv2.COLOR_GRAY2BGR)
    x, y, w, h = [int(round(v * s)) for v in roi_px]
    cv2.rectangle(img, (x, y), (x + w - 1, y + h - 1), COLORS["accent"], 1)
    return img


# ----------------------------------------------------------------- teaching
def match_teach_view(sig, f, area, models):
    """Which teaching view (if any) a blob belongs to."""
    best = None
    for m in models:
        r = area / m["unit"]
        if not 0.72 <= r <= 1.38:
            continue
        sc = shape_dist(m["sigs"], m["feats"], sig, f) if (area >= 300 and m["sigs"]) else 0.0
        if sc > max(0.45, m.get("thresh", 0.4)):
            continue
        key = abs(r - 1) + sc
        if best is None or key < best[0]:
            best = (key, m)
    return best[1] if best else None


def draw_teach(small, scale, blobs, labels, views_by_id):
    img = small.copy()
    for b, lab in zip(blobs, labels):
        c = np.round(b["c"].astype(np.float32) * scale).astype(np.int32)
        x, y, w, h = cv2.boundingRect(c)
        t = lab["t"]
        if t == "view" and lab["id"] in views_by_id:
            v = views_by_id[lab["id"]]
            col = bgr(v["color"])
            cv2.drawContours(img, [c], -1, col, 3, cv2.LINE_AA)
            label(img, v["tag"], x + w // 2 - 10, y - 4, col, 0.7)
        elif t == "ignore":
            col = COLORS["foreign"]
            cv2.drawContours(img, [c], -1, col, 2, cv2.LINE_AA)
            cv2.line(img, (x, y), (x + w, y + h), col, 2, cv2.LINE_AA)
            cv2.line(img, (x + w, y), (x, y + h), col, 2, cv2.LINE_AA)
        else:
            col = COLORS["skip"]
            cv2.drawContours(img, [c], -1, col, 1, cv2.LINE_AA)
            why = lab.get("why", "")
            if why:
                label(img, why, x, y - 4, col, 0.45)
    return img
