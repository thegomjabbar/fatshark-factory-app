"""Camera sources: Raspberry Pi camera (picamera2), USB webcam, or a synthetic demo board."""
import math
import time

import cv2
import numpy as np


class Camera:
    def __init__(self, size=(2304, 1296), source="auto"):
        self.size = size
        self.kind = None
        self.error = ""
        self.picam = None
        self.cap = None
        self.has_af = False
        self.last_md = {}

        if source in ("auto", "picamera"):
            try:
                from picamera2 import Picamera2
                self.picam = Picamera2()
                # RGB888 in picamera2 is stored B,G,R in memory, which is what OpenCV expects.
                cfg = self.picam.create_video_configuration(
                    main={"size": tuple(size), "format": "RGB888"}, buffer_count=4)
                self.picam.configure(cfg)
                self.picam.start()
                self.has_af = "AfMode" in self.picam.camera_controls
                self.kind = "picamera2"
            except Exception as e:  # no camera, no library, camera busy...
                self.error = f"Pi camera unavailable: {e}"
                self.picam = None

        if not self.kind and source in ("auto", "usb"):
            cap = cv2.VideoCapture(0)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, size[0])
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, size[1])
                ok, _ = cap.read()
                if ok:
                    self.cap = cap
                    self.kind = "usb"
            if not self.kind:
                cap.release()

        if not self.kind:
            self.kind = "demo"
            self.demo = DemoBoard(size)

    def read(self):
        if self.kind == "picamera2":
            req = self.picam.capture_request()
            try:
                frame = req.make_array("main")
                md = req.get_metadata()
            finally:
                req.release()
            self.last_md = {
                "exposure_us": md.get("ExposureTime"),
                "gain": round(md.get("AnalogueGain", 0) or 0, 2),
                "lens": round(md["LensPosition"], 2) if md.get("LensPosition") is not None else None,
                "lux": round(md["Lux"], 1) if md.get("Lux") is not None else None,
            }
            return frame
        if self.kind == "usb":
            ok, frame = self.cap.read()
            if not ok:
                raise RuntimeError("USB camera read failed")
            return frame
        return self.demo.frame()

    def apply(self, cam):
        """cam = {auto_exposure, exposure_us, gain, focus (None = autofocus)}"""
        if self.kind != "picamera2":
            return
        ctrl = {}
        hz = int(cam.get("flicker", 60) or 0)
        period = int(round(1_000_000 / (2 * hz))) if hz else 0      # lights flicker at twice mains frequency
        if cam.get("auto_exposure", True):
            ctrl["AeEnable"] = True
            if "AeFlickerMode" in self.picam.camera_controls:
                if period:
                    ctrl.update(AeFlickerMode=1, AeFlickerPeriod=period)   # manual flicker period
                else:
                    ctrl["AeFlickerMode"] = 0
        else:
            exp = int(cam.get("exposure_us", 8000))
            if period and exp >= 0.75 * period:
                exp = max(1, round(exp / period)) * period        # whole flicker cycles = no light bands
            ctrl.update(AeEnable=False, ExposureTime=exp, AnalogueGain=float(cam.get("gain", 1.0)))
        if self.has_af:
            lp = cam.get("focus")
            if lp is None:
                ctrl["AfMode"] = 2          # continuous
            else:
                ctrl["AfMode"] = 0          # manual
                ctrl["LensPosition"] = float(lp)
        self.picam.set_controls(ctrl)


class DemoBoard:
    """Synthetic backlit board for trying the app without a camera.
    L-brackets (some flipped, a few clumped) plus one washer as a foreign part."""
    PART = np.array([(0, 0), (64, 0), (64, 20), (22, 20), (22, 54), (0, 54)], np.float32)

    def __init__(self, size):
        self.W, self.H = size
        self.next_reset = 0.0
        self.base = None

    def _poly(self, cx, cy, ang, flip):
        pts = self.PART - self.PART.mean(axis=0)
        if flip:
            pts[:, 0] *= -1
        a = math.radians(ang)
        R = np.array([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]], np.float32)
        return (pts @ R.T + (cx, cy)).astype(np.int32)

    def _build(self):
        rng = np.random.default_rng()
        img = np.full((self.H, self.W, 3), 236, np.uint8)
        self.cycle = getattr(self, "cycle", 0) + 1
        if self.cycle % 3 == 0:          # every third scene the board is cleared
            self.base = img.astype(np.int16)
            return
        m, centers = 90, []
        want = int(rng.integers(24, 36)) + 1
        for _ in range(4000):
            if len(centers) >= want:
                break
            cx, cy = rng.uniform(m, self.W - m), rng.uniform(m, self.H - m)
            if all((cx - x) ** 2 + (cy - y) ** 2 > 95 ** 2 for x, y in centers):
                centers.append((cx, cy))
        washer = centers.pop()
        sides = [centers.pop() for _ in range(int(rng.integers(3, 6)))]
        polys = [self._poly(cx, cy, rng.uniform(0, 360), rng.random() < 0.5) for cx, cy in centers]
        side = np.array([(0, 0), (64, 0), (64, 9), (0, 9)], np.float32)
        for cx, cy in sides:            # parts standing on edge: narrow "side view" silhouette
            a = np.radians(rng.uniform(0, 180))
            R = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]], np.float32)
            polys.append(((side - side.mean(axis=0)) @ R.T + (cx, cy)).astype(np.int32))
        for _ in range(int(rng.integers(0, 2))):
            cx, cy = centers[int(rng.integers(len(centers)))]
            polys.append(self._poly(cx + rng.uniform(-22, 22), cy + rng.uniform(-22, 22),
                                    rng.uniform(0, 360), False))
        for p in polys:
            cv2.fillPoly(img, [p], (40, 40, 42), cv2.LINE_AA)
        wx, wy = int(washer[0]), int(washer[1])
        cv2.circle(img, (wx, wy), 26, (40, 40, 42), -1, cv2.LINE_AA)
        cv2.circle(img, (wx, wy), 10, (236, 236, 236), -1, cv2.LINE_AA)
        self.base = img.astype(np.int16)

    def _belt(self):
        """Moving-belt demo: parts ride left to right at a steady speed."""
        rng = np.random.default_rng()
        if not hasattr(self, "items"):
            self.items, self.gap = [], 0
            self.belt = np.full((self.H, self.W, 3), 236, np.uint8)
        speed = 14
        for it in self.items:
            it["x"] += speed
        self.items = [it for it in self.items if it["x"] < self.W + 120]
        self.gap -= speed
        if self.gap <= 0:
            r = rng.random()
            kind = "part" if r < 0.86 else "side" if r < 0.92 else "clump" if r < 0.97 else "washer"
            self.items.append({"x": -80, "y": float(rng.uniform(140, self.H - 140)), "a": float(rng.uniform(0, 360)),
                               "flip": bool(rng.random() < 0.5), "kind": kind})
            self.gap = int(rng.integers(110, 230))
        img = self.belt.copy()
        side = np.array([(0, 0), (64, 0), (64, 9), (0, 9)], np.float32)
        for it in self.items:
            if it["kind"] == "washer":
                cv2.circle(img, (int(it["x"]), int(it["y"])), 26, (40, 40, 42), -1, cv2.LINE_AA)
                cv2.circle(img, (int(it["x"]), int(it["y"])), 10, (236, 236, 236), -1, cv2.LINE_AA)
                continue
            if it["kind"] == "side":
                a = np.radians(it["a"])
                R = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]], np.float32)
                polys = [((side - side.mean(axis=0)) @ R.T + (it["x"], it["y"])).astype(np.int32)]
            else:
                polys = [self._poly(it["x"], it["y"], it["a"], it["flip"])]
                if it["kind"] == "clump":
                    polys.append(self._poly(it["x"] + 18, it["y"] + 14, it["a"] + 70, False))
            for p in polys:
                cv2.fillPoly(img, [p], (40, 40, 42), cv2.LINE_AA)
        return img.astype(np.int16)

    def frame(self):
        now = time.time()
        if getattr(self, "conveyor", False):
            base = self._belt()
            time.sleep(1 / 15)
            noise = np.random.randint(-6, 7, base.shape, dtype=np.int16)
            return np.clip(base + noise, 0, 255).astype(np.uint8)
        if now >= self.next_reset:
            self._build()
            self.next_reset = now + 8
        time.sleep(1 / 15)
        noise = np.random.randint(-6, 7, self.base.shape, dtype=np.int16)
        return np.clip(self.base + noise, 0, 255).astype(np.uint8)
