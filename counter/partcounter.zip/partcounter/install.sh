#!/usr/bin/env bash
# Part Counter installer for Raspberry Pi OS (Bookworm or newer) on a Pi 5.
# Run from inside the partcounter folder:   bash install.sh
set -e
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
RUN_USER="${SUDO_USER:-$USER}"
PORT="${PORT:-8080}"

echo "== Installing system packages (picamera2, OpenCV, Flask) =="
sudo apt update
sudo apt install -y python3-picamera2 python3-opencv python3-flask python3-numpy avahi-daemon

mkdir -p "$APP_DIR/data"

echo "== Allowing the counter's Shut down / Restart buttons =="
RULE_USER="${SUDO_USER:-$USER}"
TMPR="$(mktemp)"
echo "$RULE_USER ALL=(root) NOPASSWD: /usr/bin/systemctl poweroff, /usr/bin/systemctl reboot" > "$TMPR"
if sudo visudo -cf "$TMPR" >/dev/null; then
  sudo install -m 0440 -o root -g root "$TMPR" /etc/sudoers.d/partcounter
fi
rm -f "$TMPR"

echo "== Installing service so the counter starts on boot =="
sudo tee /etc/systemd/system/partcounter.service >/dev/null <<UNIT
[Unit]
Description=Part Counter (backlit part counting)
After=network-online.target
Wants=network-online.target

[Service]
User=$RUN_USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/python3 $APP_DIR/app.py --port $PORT
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable --now partcounter.service
sleep 3
sudo systemctl --no-pager --lines=5 status partcounter.service || true

echo
echo "== Done. Open one of these in a browser on any connected computer =="
echo "   http://$(hostname).local:$PORT"
for ip in $(hostname -I); do echo "   http://$ip:$PORT"; done
echo
echo "Logs:     journalctl -u partcounter -f"
echo "Restart:  sudo systemctl restart partcounter"
