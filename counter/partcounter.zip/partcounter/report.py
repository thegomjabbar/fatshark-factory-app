"""Downloadable run report: a self-contained HTML page (with capture photos) plus
the matching CSV rows and full-size photos, zipped together."""
import base64
import csv
import datetime
import html
import io
import statistics
import zipfile
from collections import Counter, defaultdict

import cv2


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _pct(a, b):
    return f"{100 * a / b:.0f}%" if b else "–"


def _dur(seconds):
    seconds = int(round(seconds))
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m"


def _thumb(path, width=260):
    img = cv2.imread(str(path))
    if img is None:
        return ""
    h, w = img.shape[:2]
    if w > width:
        img = cv2.resize(img, (width, int(h * width / w)), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 70])
    return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode() if ok else ""


def filter_rows(rows, day_from=None, day_to=None, order_name=None):
    out = []
    for r in rows:
        day = (r.get("timestamp") or "")[:10]
        if day_from and day < day_from:
            continue
        if day_to and day > day_to:
            continue
        if order_name and r.get("order") != order_name:
            continue
        out.append(r)
    return out


def accuracy(rows):
    """Per-part accuracy numbers from logged captures."""
    by_part = defaultdict(list)
    for r in rows:
        by_part[r.get("part") or "(no part)"].append(r)
    out = []
    for part, rs in sorted(by_part.items()):
        n = len(rs)
        with_stats = [r for r in rs if r.get("batch_s") not in ("", None)]
        clean = sum(1 for r in with_stats if _f(r.get("flagged_s")) == 0 and _f(r.get("operator_confirmed")) == 0)
        confirmed = sum(1 for r in rs if _f(r.get("operator_confirmed")) > 0)
        kits = [r for r in rs if r.get("kit_ok") in ("yes", "no")]
        kit_ok = sum(1 for r in kits if r["kit_ok"] == "yes")
        flags = Counter()
        for r in rs:
            for key, label in (("max_touching", "touching"), ("max_wrong_shape", "wrong shape"), ("max_too_small", "too small")):
                if _f(r.get(key)) > 0:
                    flags[label] += 1
        times = [_f(r["batch_s"]) for r in with_stats]
        flagged = [_f(r.get("flagged_s")) for r in with_stats]
        out.append({
            "part": part, "captures": n, "parts": sum(int(_f(r.get("count"))) for r in rs),
            "first_time_right": _pct(clean, len(with_stats)),
            "needed_confirm": _pct(confirmed, n),
            "kit_hit": _pct(kit_ok, len(kits)),
            "avg_time": _dur(statistics.mean(times)) if times else "–",
            "avg_flagged": _dur(statistics.mean(flagged)) if flagged else "–",
            "top_flag": (f"{flags.most_common(1)[0][0]} ({flags.most_common(1)[0][1]}×)" if flags else "none"),
            "manual": sum(1 for r in rs if r.get("capture") == "manual"),
        })
    return out


CSS = """
:root{--accent:#6d4fd8;--soft:#efeaff;--line:#ddd6f5;--dim:#6b6585;--ok:#15803d;--bad:#b91c1c}
*{box-sizing:border-box}body{margin:0;font:14px/1.45 "Segoe UI",system-ui,Arial,sans-serif;color:#1d1830;background:#fff}
main{max-width:1100px;margin:0 auto;padding:28px}
h1{margin:0;font-size:26px}h2{margin:30px 0 10px;font-size:19px;color:var(--accent);border-bottom:2px solid var(--line);padding-bottom:6px}
h3{margin:18px 0 8px;font-size:16px}
.meta{color:var(--dim);margin-top:4px}
.kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-top:18px}
.kpi{background:var(--soft);border-radius:10px;padding:12px 14px}.kpi b{display:block;font-size:24px}.kpi span{color:var(--dim);font-size:13px}
table{width:100%;border-collapse:collapse;margin-top:6px}th{text-align:left;font-size:12.5px;color:var(--dim);border-bottom:2px solid var(--line);padding:6px}
td{padding:6px;border-bottom:1px solid var(--line);vertical-align:top}
.ok{color:var(--ok);font-weight:700}.bad{color:var(--bad);font-weight:700}
.caps{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
.cap{border:1px solid var(--line);border-radius:10px;overflow:hidden;break-inside:avoid}
.cap img{width:100%;display:block;background:#eee}.cap div{padding:8px 10px;font-size:13px}.cap b{font-size:15px}
.note{background:var(--soft);border-radius:10px;padding:10px 14px;color:var(--dim);font-size:13px}
@media print{main{padding:0}h2{break-after:avoid}.cap{break-inside:avoid}}
"""


def build(rows, orders, station, version, title, photos_dir, include_photos=True):
    esc = html.escape
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    total_parts = sum(int(_f(r.get("count"))) for r in rows)
    kits = [r for r in rows if r.get("kit_ok") in ("yes", "no")]
    ok_kits = sum(1 for r in kits if r["kit_ok"] == "yes")
    ops = Counter(r.get("operator") or "(not signed in)" for r in rows)
    days = sorted({(r.get("timestamp") or "")[:10] for r in rows})
    span = f"{days[0]} to {days[-1]}" if len(days) > 1 else (days[0] if days else "no captures")

    h = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>{esc(title)}</title>"
         f"<meta name='viewport' content='width=device-width,initial-scale=1'><style>{CSS}</style></head><body><main>"]
    h.append(f"<h1>{esc(title)}</h1><div class='meta'>Station {esc(station)} · Part Counter {esc(version)} · "
             f"{esc(span)} · made {esc(now)}</div>")
    h.append("<div class='kpis'>"
             f"<div class='kpi'><b>{len(rows)}</b><span>captures</span></div>"
             f"<div class='kpi'><b>{total_parts:,}</b><span>parts counted</span></div>"
             f"<div class='kpi'><b>{ok_kits}</b><span>good kits</span></div>"
             f"<div class='kpi'><b>{len(kits) - ok_kits}</b><span>not-full kits</span></div>"
             f"<div class='kpi'><b>{sum(1 for r in rows if r.get('capture') == 'auto')}</b><span>auto captures</span></div>"
             f"<div class='kpi'><b>{len(ops)}</b><span>operators</span></div></div>")

    # orders
    names = []
    for r in rows:
        key = (r.get("order"), r.get("part"))
        if r.get("order") and key not in names:
            names.append(key)
    if names:
        h.append("<h2>Orders</h2><table><tr><th>Order</th><th>Part</th><th>Per kit</th><th>Kits</th>"
                 "<th>Good / not full</th><th>Started</th><th>Last capture</th><th>Time</th><th>Kits per hour</th><th>Operators</th></tr>")
        for name, part in names:
            rs = [r for r in rows if r.get("order") == name and r.get("part") == part]
            o = next((o for o in orders if o["name"] == name and o["part"] == part), None)
            good = sum(1 for r in rs if r.get("kit_ok") == "yes")
            t0 = datetime.datetime.fromisoformat(rs[0]["timestamp"])
            t1 = datetime.datetime.fromisoformat(rs[-1]["timestamp"])
            secs = (t1 - t0).total_seconds()
            rate = f"{good / (secs / 3600):.1f}" if secs > 60 and good > 1 else "–"
            if o and o.get("kind") == "total":
                kits_txt = f"{o.get('done_parts', 0)} of {o['total']} parts in {o['done']} piles"
            else:
                kits_txt = (f"{o['done']} of {o['batches']}" if o and o["batches"] else (f"{o['done']}" if o else "?"))
            if o and o.get("status") == "complete":
                kits_txt += " <span class='ok'>complete</span>"
            h.append(f"<tr><td><b>{esc(name)}</b></td><td>{esc(rs[0].get('part', ''))}</td><td>{esc((str(o['per_batch']) if o.get('kind') != 'total' else 'fill total') if o else rs[0].get('target', ''))}</td>"
                     f"<td>{kits_txt}</td><td><span class='ok'>{good}</span> / <span class='bad'>{len(rs) - good}</span></td>"
                     f"<td>{esc(rs[0]['timestamp'][5:16].replace('T', ' '))}</td><td>{esc(rs[-1]['timestamp'][5:16].replace('T', ' '))}</td>"
                     f"<td>{_dur(secs)}</td><td>{rate}</td><td>{esc(', '.join(sorted({r.get('operator') or '–' for r in rs})))}</td></tr>")
        h.append("</table>")

    # accuracy
    acc = accuracy(rows)
    if acc:
        h.append("<h2>Accuracy</h2><table><tr><th>Part</th><th>Captures</th><th>Parts</th><th>First time right</th>"
                 "<th>Needed operator count</th><th>Kit hit rate</th><th>Avg time per pile</th><th>Avg time flagged</th>"
                 "<th>Most common flag</th><th>Manual captures</th></tr>")
        for a in acc:
            h.append(f"<tr><td><b>{esc(a['part'])}</b></td><td>{a['captures']}</td><td>{a['parts']:,}</td><td>{a['first_time_right']}</td>"
                     f"<td>{a['needed_confirm']}</td><td>{a['kit_hit']}</td><td>{a['avg_time']}</td><td>{a['avg_flagged']}</td>"
                     f"<td>{esc(a['top_flag'])}</td><td>{a['manual']}</td></tr>")
        h.append("</table><p class='note'><b>First time right</b>: piles that were never flagged and needed no operator count. "
                 "<b>Needed operator count</b>: an operator tapped a touching group to say how many it was. "
                 "<b>Kit hit rate</b>: captures during an order that had exactly the kit quantity. "
                 "<b>Time per pile</b>: from parts landing on the board to the capture. A part with a low first-time-right "
                 "score usually needs better teaching, lighting, or parts spread further apart.</p>")

    # operators
    h.append("<h2>Operators</h2><table><tr><th>Operator</th><th>Captures</th><th>Parts</th><th>Good kits</th><th>Avg time per pile</th></tr>")
    for name, n in ops.most_common():
        rs = [r for r in rows if (r.get("operator") or "(not signed in)") == name]
        times = [_f(r["batch_s"]) for r in rs if r.get("batch_s") not in ("", None)]
        h.append(f"<tr><td>{esc(name)}</td><td>{n}</td><td>{sum(int(_f(r.get('count'))) for r in rs):,}</td>"
                 f"<td>{sum(1 for r in rs if r.get('kit_ok') == 'yes')}</td><td>{_dur(statistics.mean(times)) if times else '–'}</td></tr>")
    h.append("</table>")

    # captures
    h.append(f"<h2>Captures ({len(rows)})</h2>")
    if include_photos:
        h.append("<div class='caps'>")
        for r in rows:
            src = _thumb(photos_dir / r["photo"]) if r.get("photo") and (photos_dir / r["photo"]).exists() else ""
            kit = (" <span class='ok'>✓ kit</span>" if r.get("kit_ok") == "yes" else
                   " <span class='bad'>✗ not full</span>" if r.get("kit_ok") == "no" else "")
            extra = []
            if _f(r.get("operator_confirmed")):
                extra.append(f"{int(_f(r['operator_confirmed']))} counted by operator")
            if _f(r.get("flagged_s")):
                extra.append(f"flagged {_dur(_f(r['flagged_s']))}")
            img = (f"<a href='photos/{esc(r['photo'])}'><img src='{src}' alt='Capture photo'></a>" if src
                   else "<div style='padding:30px;color:#999'>photo not kept</div>")
            h.append(f"<div class='cap'>{img}<div><b>{esc(r.get('count', ''))}"
                     f"{('/' + esc(r['target'])) if r.get('target') else ''}</b> {esc(r.get('part', ''))}{kit}<br>"
                     f"{esc(r['timestamp'][:16].replace('T', ' '))} · {esc(r.get('operator') or '–')} · {esc(r.get('capture', ''))}"
                     f"{('<br>' + esc(r['order'])) if r.get('order') else ''}{('<br>' + esc(', '.join(extra))) if extra else ''}</div></div>")
        h.append("</div>")
    else:
        h.append("<table><tr><th>Time</th><th>Order</th><th>Part</th><th>Count</th><th>Kit</th><th>Operator</th><th>How</th></tr>")
        for r in rows:
            h.append(f"<tr><td>{esc(r['timestamp'][:16].replace('T', ' '))}</td><td>{esc(r.get('order', ''))}</td><td>{esc(r.get('part', ''))}</td>"
                     f"<td>{esc(r.get('count', ''))}</td><td>{esc(r.get('kit_ok', ''))}</td><td>{esc(r.get('operator', ''))}</td><td>{esc(r.get('capture', ''))}</td></tr>")
        h.append("</table>")
    h.append("</main></body></html>")

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("report.html", "".join(h))
        s = io.StringIO()
        if rows:
            w = csv.DictWriter(s, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        z.writestr("captures.csv", s.getvalue())
        if include_photos:
            for r in rows:
                p = photos_dir / r["photo"] if r.get("photo") else None
                if p and p.exists():
                    z.write(p, f"photos/{r['photo']}", compress_type=zipfile.ZIP_STORED)
    return buf.getvalue()


def validation_sheet(runs, photos_dir, station, version, blank=False, part=None):
    """Printable accuracy test record: the counter's count vs. a hand count, per part."""
    esc = html.escape
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    css = CSS + """
    .pass{color:var(--ok);font-weight:800}.fail{color:var(--bad);font-weight:800}
    .blank td{height:34px}.sig{display:grid;grid-template-columns:1fr 1fr;gap:30px;margin-top:40px}
    .sig div{border-top:1.5px solid #333;padding-top:6px;color:var(--dim);font-size:13px}
    .thumb{width:110px;border-radius:6px;display:block}
    """
    h = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>Part Counter accuracy test</title>"
         f"<style>{css}</style></head><body><main>"]
    h.append(f"<h1>Part Counter accuracy test</h1><div class='meta'>Station {esc(station)} · software {esc(version)} · printed {esc(now)}</div>")
    h.append("<p class='note' style='margin-top:14px'><b>How to test:</b> hand-count a known quantity of one part (for example 100). "
             "Pour it on the board, spread it like an operator would, and record what the counter says. Repeat 5 times, "
             "mixing the parts up between runs. Include touching parts and one wrong part. "
             "<b>Pass</b> = the counter's number equals the hand count with no unsure groups.</p>")
    if blank:
        h.append("<h2>Test runs</h2><table class='blank'><tr><th>Run</th><th>Date / time</th><th>Part / part number</th><th>Hand count</th>"
                 "<th>Counter said</th><th>Difference</th><th>Pass?</th><th>Tester</th><th>Notes</th></tr>")
        for i in range(1, 16):
            h.append(f"<tr><td>{i}</td>" + "<td></td>" * 8 + "</tr>")
        h.append("</table>")
    else:
        rs = [r for r in runs if not part or r["part"] == part]
        if not rs:
            h.append("<p>No test runs recorded yet.</p>")
        parts = []
        for r in rs:
            if r["part"] not in parts:
                parts.append(r["part"])
        h.append("<h2>Summary</h2><table><tr><th>Part</th><th>Runs</th><th>Passed</th><th>Parts hand-counted</th>"
                 "<th>Parts counted</th><th>Accuracy</th><th>Result</th></tr>")
        for p in parts:
            pr = [r for r in rs if r["part"] == p]
            ok = sum(1 for r in pr if r["pass"])
            tot_true = sum(r["true"] for r in pr)
            err = sum(abs(r["diff"]) for r in pr)
            acc = f"{100 * (1 - err / tot_true):.2f}%" if tot_true else "–"
            res = "<span class='pass'>PASS</span>" if ok == len(pr) and len(pr) >= 5 else (
                  "<span class='fail'>NOT YET</span>" if ok < len(pr) else f"{len(pr)} of 5 runs done")
            h.append(f"<tr><td><b>{esc(p)}</b></td><td>{len(pr)}</td><td>{ok}</td><td>{tot_true:,}</td>"
                     f"<td>{sum(r['counted'] for r in pr):,}</td><td>{acc}</td><td>{res}</td></tr>")
        h.append("</table>")
        for p in parts:
            pr = [r for r in rs if r["part"] == p]
            h.append(f"<h2>{esc(p)}</h2><table><tr><th>#</th><th>Time</th><th>Hand count</th><th>Counter</th><th>Diff</th>"
                     "<th>Touching groups</th><th>Unsure</th><th>Wrong parts</th><th>Result</th><th>Tester</th><th>Note</th><th>Photo</th></tr>")
            for i, r in enumerate(pr, 1):
                src = _thumb(photos_dir / r["photo"], 220) if r.get("photo") and (photos_dir / r["photo"]).exists() else ""
                img = "<img class='thumb' src='" + src + "' alt=''>" if src else ""
                res = "<span class='pass'>PASS</span>" if r["pass"] else "<span class='fail'>FAIL</span>"
                when = esc(r["time"][5:16].replace("T", " "))
                h.append(f"<tr><td>{i}</td><td>{when}</td><td>{r['true']}</td><td>{r['counted']}</td>"
                         f"<td>{r['diff']:+d}</td><td>{r.get('groups', 0)}</td><td>{r['unsure_groups']}</td><td>{r.get('wrong', 0)}</td>"
                         f"<td>{res}</td><td>{esc(r.get('operator', ''))}</td><td>{esc(r.get('note', ''))}</td><td>{img}</td></tr>")
            h.append("</table>")
    h.append("<div class='sig'><div>Tested by / date</div><div>Approved by / date</div></div></main></body></html>")
    return "".join(h)
