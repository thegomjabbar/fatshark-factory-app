#!/usr/bin/env python3
"""Part Counter - backlit small-part counting server for Raspberry Pi 5.

Runs on the Pi. Any computer on the same network opens it in a browser:
    http://<pi-hostname>.local:8080
"""
import argparse
import collections
import io
import shutil
import tempfile
import urllib.request
import zipfile
import copy
import csv
import datetime
import json
import os
import socket
import threading
import time
from pathlib import Path

import cv2
from flask import Flask, Response, jsonify, request, send_file, send_from_directory

import conveyor
import report
import vision
from camera import Camera

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
SETTINGS_F = DATA / "settings.json"
PROFILES_F = DATA / "profiles.json"
LOG_F = DATA / "count_log.csv"
UPDATE_URL_F = DATA / "update_url.txt"


def app_version():
    try:
        return (BASE / "VERSION").read_text().strip()
    except OSError:
        return "dev"
LOG_HEADER = ["timestamp", "order", "part", "count", "target", "kit_ok", "operator", "confirmed_singles",
              "clumps", "operator_confirmed", "flags", "capture", "batch_s", "flagged_s", "max_touching",
              "max_wrong_shape", "max_too_small", "note", "photo", "capture_id"]
OPERATORS_F = DATA / "operators.json"
ORDERS_F = DATA / "orders.json"
CAPTURES = DATA / "captures"
CAPTURES.mkdir(exist_ok=True)
MAX_PHOTOS = 3000

DEFAULT_CAMERA = {"auto_exposure": True, "exposure_us": 8000, "gain": 1.0, "focus": None}

SETTING_TYPES = {
    "threshold_mode": (str, None), "threshold": (int, (0, 255)), "dark_parts": (bool, None),
    "blur": (int, (0, 10)), "morph": (int, (0, 10)), "min_area_px": (int, (1, 10_000_000)),
    "single_tol": (float, (0.05, 1.0)), "shape_check": (bool, None), "ignore_edge": (bool, None),
    "target": (int, (0, 1_000_000)), "stream_width": (int, (320, 4096)),
    "auto_capture": (str, None), "capture_hold": (float, (0.3, 10.0)), "clear_hold": (float, (0.3, 10.0)),
    "require_signin": (bool, None), "auto_print": (bool, None),
    "label_w": (float, (0.5, 8.0)), "label_h": (float, (0.5, 8.0)),
    "station_mode": (str, None), "conv_dir": (str, None), "conv_line": (float, (0.05, 0.95)),
    "conv_max_jump": (float, (0.03, 0.6)),
}
CAMERA_TYPES = {"auto_exposure": (bool, None), "exposure_us": (int, (50, 500_000)),
                "gain": (float, (1.0, 16.0)), "focus": (float, (0.0, 32.0))}


def load_json(p, default):
    try:
        return json.loads(p.read_text())
    except Exception:
        return copy.deepcopy(default)


def save_json(p, obj):
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=1))
    os.replace(tmp, p)


def coerce(d, types):
    out = {}
    for k, v in d.items():
        if k not in types:
            continue
        typ, rng = types[k]
        if v is None or v == "":
            out[k] = None
            continue
        v = (str(v).lower() in ("1", "true", "yes", "on")) if typ is bool and isinstance(v, str) else typ(v)
        if rng:
            v = max(rng[0], min(rng[1], v))
        out[k] = v
    return out


def append_log(row):
    if LOG_F.exists():
        with open(LOG_F, newline="") as f:
            head = next(csv.reader(f), None)
        if head != LOG_HEADER:   # older format: keep it, start a fresh file
            LOG_F.rename(DATA / f"count_log_old_{int(time.time())}.csv")
    new = not LOG_F.exists()
    with open(LOG_F, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(LOG_HEADER)
        w.writerow(row)


class Engine:
    def __init__(self, cam):
        self.cam = cam
        self.cond = threading.Condition()
        stored = load_json(SETTINGS_F, {})
        self.settings = {**vision.DEFAULT_SETTINGS,
                         **{k: v for k, v in stored.items() if k in vision.DEFAULT_SETTINGS}}
        self.camera_cfg = {**DEFAULT_CAMERA, **stored.get("camera", {})}
        self.orders = load_json(ORDERS_F, {"active": None, "items": []})
        if not isinstance(self.orders, dict) or not isinstance(self.orders.get("items"), list):
            self.orders = {"active": None, "items": []}
        self.eng_pin = str(stored.get("eng_pin", "1064") or "")
        self.operators = load_json(OPERATORS_F, {"items": [], "current": None, "since": None})
        if not isinstance(self.operators, dict) or not isinstance(self.operators.get("items"), list):
            self.operators = {"items": [], "current": None, "since": None}
        self.batch = None                 # stats for the pile currently on the board
        self.conv = conveyor.Tracker()
        self.last_fp = None               # where the parts of the last capture were (duplicate guard)
        self.rt_prev = None               # running total: last settled count on the board
        self.rt_since = None
        self.dup = None
        self.profiles = load_json(PROFILES_F, {"active": None, "items": {}})
        if not isinstance(self.profiles, dict) or not isinstance(self.profiles.get("items"), dict):
            self.profiles = {"active": None, "items": {}}
        for p in self.profiles["items"].values():
            vision.migrate_profile(p)
        self.prof_ver = 1
        self.frame = None
        self.blobs = []
        self.summary = {}
        self.views = {}
        self.frame_id = 0
        self.fps = 0.0
        self.error = ""
        self.hist = collections.deque(maxlen=6)
        self.confirms = []                # operator-confirmed groups: {x, y, area, n}
        self.empty_since = None
        # auto capture
        self.cap_state = "ready"          # ready | captured
        self.cap_since = None
        self.clear_since = None
        self.last_capture = None
        self.capture_id = 0
        self.batch_day = datetime.date.today()
        self.batches_today = 0
        try:
            self.cam.apply(self.camera_cfg)
        except Exception as e:
            self.error = f"Camera settings rejected: {e}"
        threading.Thread(target=self._loop, daemon=True).start()

    # ---- helpers (call with self.cond held)
    def active_profile(self):
        a = self.profiles.get("active")
        return self.profiles["items"].get(a) if a else None

    def persist_settings(self):
        save_json(SETTINGS_F, {**self.settings, "camera": self.camera_cfg, "eng_pin": self.eng_pin})

    def persist_orders(self):
        save_json(ORDERS_F, self.orders)

    def persist_operators(self):
        save_json(OPERATORS_F, self.operators)

    def current_operator(self):
        cid = self.operators.get("current")
        return next((o for o in self.operators["items"] if o["id"] == cid), None) if cid else None

    def signin_needed(self):
        return bool(self.settings.get("require_signin", True) and not self.current_operator())

    # ---- duplicate guard: the same pile can't be logged twice
    @staticmethod
    def fingerprint(blobs):
        out = []
        for b in blobs:
            if b["kind"] in ("single", "clump", "confirmed", "partial", "foreign"):
                x, y = vision.blob_center(b)
                out.append((x, y, b["area"]))
        return out

    @staticmethod
    def pile_overlap(cur, ref):
        """How many parts of the reference pile are still lying in the same place."""
        n = 0
        for rx, ry, ra in ref:
            tol = max(20.0, 0.5 * ra ** 0.5)
            for cx, cy, ca in cur:
                if abs(cx - rx) <= tol and abs(cy - ry) <= tol and 0.75 <= ca / ra <= 1.33:
                    n += 1
                    break
        return n

    def _check_dup(self, blobs, now):
        if not self.last_fp:
            self.dup = None
            return
        if self.empty_since and now - self.empty_since >= float(self.settings.get("clear_hold", 1.0)):
            self.last_fp, self.dup = None, None      # board was cleared: anything new is a new pile
            return
        cur = self.fingerprint(blobs)
        ref = self.last_fp["pts"]
        if not ref or not cur:
            self.dup = None
            return
        m = self.pile_overlap(cur, ref)
        if m >= 0.8 * len(ref) and abs(len(cur) - len(ref)) <= max(1, 0.1 * len(ref)):
            self.dup = {"kind": "same", "n": m}
        elif self.last_fp["accepted"] and m >= max(1, 0.3 * len(ref)):
            self.dup = {"kind": "leftover", "n": m}
        else:
            self.dup = None

    def _bank(self, n, mode):
        """Add n parts to the running total and log them (call with lock held)."""
        counts = dict(self.summary.get("counts", {}))
        counts["clump"] = 0
        self.capture(mode, override={"estimated": n, "confirmed": n, "operator_parts": 0, "clump_parts": 0,
                                     "attention_count": 0, "counts": counts, "stable": True})

    def _running_total(self, summary, now):
        """Fill-a-total orders: the board is a staging area. Parts can be added any time;
        moving them around changes nothing. Parts taken off the board (into the bag) are
        added to the total, except extras removed to get back down to what's needed.
        When the board holds exactly what's still needed, the order completes."""
        o = self.active_order()
        if not summary.get("stable") or summary["attention_count"] > 0:
            self.rt_since = None
            return
        c = summary["estimated"]
        if self.rt_prev is None:
            self.rt_prev = c
            return
        remaining = o["total"] - o.get("done_parts", 0)
        if c < self.rt_prev:
            removed = self.rt_prev - c
            over = max(0, self.rt_prev - remaining)        # extras above what was still needed
            bag = removed - over
            if bag > 0:
                self._bank(bag, "bagged")
            self.rt_prev = c
            self.rt_since = None
            return
        if c > self.rt_prev:
            self.rt_prev = c
            self.rt_since = None
        remaining = o["total"] - o.get("done_parts", 0)
        if c > 0 and c == remaining:
            self.rt_since = self.rt_since or now
            if now - self.rt_since >= float(self.settings.get("capture_hold", 1.5)):
                self._bank(c, "final")
                self.rt_prev, self.rt_since = None, None
        else:
            self.rt_since = None

    def conveyor_override(self):
        c = self.conv
        flagged = sum(c.flags.values())
        counts = dict(self.summary.get("counts", {}))
        counts["clump"] = c.flags.get("clump", 0)
        return {"estimated": c.count, "confirmed": c.count, "operator_parts": 0, "clump_parts": 0,
                "attention_count": flagged, "counts": counts, "stable": True}

    def _conveyor_events(self, events):
        """Log kits automatically as parts pass the line (call with lock held)."""
        if not events:
            return
        order = self.active_order()
        if not order or order["status"] != "open" or self.signin_needed():
            return
        c = self.conv
        if order.get("kind") == "total":
            need = order["total"] - order.get("done_parts", 0)
            if c.count >= need:
                self.capture("conveyor", override=self.conveyor_override())
                c.reset_count()
        elif c.count >= order["per_batch"]:
            self.capture("conveyor", override=self.conveyor_override())
            c.reset_count()

    def _track_batch(self, summary, now, dt):
        """Accuracy stats for each pile: how long it took, how long it was flagged, worst flags."""
        c = summary["counts"]
        present = c["single"] + c["clump"] + c["partial"] + c["foreign"] + c["confirmed"] > 0
        if self.cap_state == "captured":
            return
        if not present:
            if self.batch and now - self.batch["last_seen"] > float(self.settings.get("clear_hold", 1.0)):
                self.batch = None          # pile removed without a capture
            return
        if not self.batch:
            self.batch = {"start": now, "flagged": 0.0, "clump": 0, "foreign": 0, "partial": 0, "last_seen": now}
        b = self.batch
        b["last_seen"] = now
        if summary["attention_count"] > 0:
            b["flagged"] += min(dt, 1.0)
        for k in ("clump", "foreign", "partial"):
            b[k] = max(b[k], c[k])

    def active_order(self):
        oid = self.orders.get("active")
        return next((o for o in self.orders["items"] if o["id"] == oid), None) if oid else None

    def select_part(self, name):
        """Make a part the one being counted, restoring the setup it was taught with."""
        if name is None:
            self.profiles["active"] = None
        else:
            p = self.profiles["items"].get(name)
            if not p:
                raise KeyError(name)
            self.profiles["active"] = name
            self.settings.update(p.get("seg", {}))
            if "roi" in p:
                self.settings["roi"] = p["roi"]
            if p.get("camera"):
                self.camera_cfg.update(p["camera"])
            self.persist_settings()
        self.cap_state = "ready"
        self.confirms = []
        self.profiles_changed()
        return dict(self.camera_cfg)

    def _save_photo(self, stamp):
        img = self.views.get("annotated")
        if img is None:
            return ""
        name = f"{stamp}.jpg"
        cv2.imwrite(str(CAPTURES / name), img, [cv2.IMWRITE_JPEG_QUALITY, 72])
        files = sorted(CAPTURES.glob("*.jpg"))
        for old in files[:-MAX_PHOTOS]:
            try:
                old.unlink()
            except OSError:
                pass
        return name

    def profiles_changed(self):
        save_json(PROFILES_F, self.profiles)
        self.prof_ver += 1
        self.hist.clear()

    def reset_stability(self):
        self.hist.clear()

    def capture(self, mode, note="", override=None):
        """Write the current count to the log. Call with self.cond held."""
        s = self.summary
        if not s:
            return None
        if override:
            s = {**s, **override}
        today = datetime.date.today()
        if today != self.batch_day:
            self.batch_day, self.batches_today = today, 0
        self.batches_today += 1
        now = datetime.datetime.now()
        order = self.active_order()
        clean = s["attention_count"] == 0 and s["clump_parts"] == 0 and s["estimated"] > 0
        if order and order.get("kind") == "total":
            left = order["total"] - order.get("done_parts", 0)
            target = left
            kit_ok = bool(order["status"] == "open" and clean and s["estimated"] <= left)
            if kit_ok:
                order["done"] += 1
                order["done_parts"] = order.get("done_parts", 0) + s["estimated"]
                if order["done_parts"] >= order["total"]:
                    order["status"] = "complete"
                    order["completed"] = now.isoformat(timespec="seconds")
                self.persist_orders()
        else:
            target = order["per_batch"] if order else (self.settings["target"] or 0)
            kit_ok = bool(order and order["status"] == "open" and s["estimated"] == order["per_batch"] and clean)
            if kit_ok:
                order["done"] += 1
                order["done_parts"] = order.get("done_parts", 0) + s["estimated"]
                if order["batches"] and order["done"] >= order["batches"]:
                    order["status"] = "complete"
                    order["completed"] = now.isoformat(timespec="seconds")
                self.persist_orders()
        photo = self._save_photo(now.strftime("%Y%m%d_%H%M%S_") + str(self.capture_id + 1))
        op = self.current_operator()
        b = (self.batch or {}) if not mode.startswith("conveyor") else {}
        t_now = time.time()
        row = [now.isoformat(timespec="seconds"), order["name"] if order else "",
               self.profiles.get("active") or "", s["estimated"], target or "",
               ("yes" if kit_ok else "no") if order else "", op["name"] if op else "",
               s["confirmed"] - s.get("operator_parts", 0), s["counts"]["clump"], s.get("operator_parts", 0),
               s["attention_count"], mode,
               round(t_now - b["start"], 1) if b else "", round(b.get("flagged", 0.0), 1) if b else "",
               b.get("clump", ""), b.get("foreign", ""), b.get("partial", ""),
               (note or "").strip()[:200], photo, self.capture_id + 1]
        append_log(row)
        self.batch = None
        if not mode.startswith("conveyor"):
            self.last_fp = {"pts": self.fingerprint(self.blobs), "accepted": kit_ok if order else True}
            self.dup = None
        self.capture_id += 1
        self.last_capture = {"count": s["estimated"], "part": row[2], "time": now.strftime("%H:%M:%S"),
                             "batch": self.batches_today, "mode": mode, "flags": s["attention_count"],
                             "order": order["name"] if order else None, "kit_ok": kit_ok,
                             "kit": order["done"] if order else None, "kits": order["batches"] if order else None,
                             "kind": order.get("kind", "kits") if order else None,
                             "done_parts": order.get("done_parts", 0) if order else None,
                             "total": order.get("total") if order else None,
                             "target": target, "photo": photo, "operator": op["name"] if op else "",
                             "id": self.capture_id, "stamp": now.isoformat(timespec="minutes")}
        return dict(zip(LOG_HEADER, row))

    def _auto_capture(self, summary, now):
        s = self.settings
        mode = s.get("auto_capture", "lock")
        if self.cap_state == "captured":
            n = summary["counts"]
            empty = n["single"] + n["clump"] + n["partial"] + n["foreign"] + n["confirmed"] == 0
            if empty:
                self.clear_since = self.clear_since or now
                if now - self.clear_since >= float(s.get("clear_hold", 1.0)):
                    self.cap_state, self.clear_since = "ready", None
            else:
                self.clear_since = None
            return
        if mode == "off" or summary["mode"] != "profile" or self.signin_needed():
            self.cap_since = None
            return
        order = self.active_order()
        if order and order["status"] != "open":
            self.cap_since = None
            return
        base = (summary.get("stable") and summary["attention_count"] == 0 and summary["estimated"] > 0
                and not self.dup)
        if order and order.get("kind") == "total":
            # fill-a-total: any clean pile that doesn't go over what's still needed is added
            ok = base and summary["estimated"] <= order["total"] - order.get("done_parts", 0)
        else:
            t = order["per_batch"] if order else int(s.get("target") or 0)
            need_target = bool(order) or mode == "target"
            ok = base and (not need_target or (t > 0 and summary["estimated"] == t))
        if ok:
            self.cap_since = self.cap_since or now
            if now - self.cap_since >= float(s.get("capture_hold", 1.5)):
                self.capture("auto")
                self.cap_state, self.cap_since = "captured", None
        else:
            self.cap_since = None

    # ---- capture + processing loop
    def _loop(self):
        last = time.time()
        compiled, compiled_key = None, None
        while True:
            try:
                frame = self.cam.read()
            except Exception as e:
                self.error = str(e)
                time.sleep(0.5)
                continue
            with self.cond:
                s = dict(self.settings)
                conv_mode = s.get("station_mode") == "conveyor"
                if conv_mode:
                    s["ignore_edge"] = False      # parts enter and leave at the edges on a belt
                if self.cam.kind == "demo":
                    self.cam.demo.conveyor = conv_mode
                prof = self.active_profile()
                confirms = list(self.confirms)
                key = (self.profiles.get("active"), self.prof_ver)
                if key != compiled_key:
                    compiled = vision.compile_profile(prof) if prof else None
                    compiled_key = key
            try:
                blobs, summary, mask, roi_px = vision.process(frame, s, compiled, confirms)
                small, sc = vision.fit_width(frame, s["stream_width"])
                events = []
                ann = vision.annotate(small, sc, blobs, roi_px)
                if conv_mode:
                    events = self.conv.update(blobs, roi_px, s) if compiled else []
                    ann = self.conv.draw(ann, sc, roi_px, s)
                views = {
                    "raw": small,
                    "annotated": ann,
                    "mask": vision.mask_view(mask, roi_px, s["stream_width"]),
                    "outlines": vision.outline_view(small, sc, blobs, roi_px),
                }
            except Exception as e:
                self.error = f"Processing error: {e}"
                time.sleep(0.2)
                continue

            if prof:
                drift = [k for k in vision.SEG_KEYS if prof.get("seg", {}).get(k) != s.get(k)]
                if drift:
                    summary["attention"].append({"kind": "drift", "text":
                        f"Detection settings changed since {prof['name']} was taught "
                        f"({', '.join(drift)}). Tap Use on the part to restore them, or teach it again."})

            now = time.time()
            dt = now - last
            last = now
            with self.cond:
                self.hist.append((summary["estimated"], summary["attention_count"]))
                summary["stable"] = len(self.hist) == self.hist.maxlen and len(set(self.hist)) == 1
                self.frame, self.blobs, self.summary, self.views = frame, blobs, summary, views
                self.fps = 0.85 * self.fps + 0.15 * (1.0 / dt if dt > 0 else 0)
                self.frame_id += 1
                self.error = ""
                c = summary["counts"]
                if c["single"] + c["clump"] + c["partial"] + c["foreign"] + c["confirmed"] == 0:
                    self.empty_since = self.empty_since or now
                    if self.confirms and now - self.empty_since > 0.5:
                        self.confirms = []      # board cleared: confirmations no longer apply
                else:
                    self.empty_since = None
                if conv_mode:
                    c = self.conv
                    summary["conveyor"] = {"count": c.count, "flags": dict(c.flags), "run_total": c.run_total,
                                           "events": list(c.events), "tracks": len(c.tracks),
                                           "idle_s": round(now - c.last_event, 1) if c.last_event else None}
                    self._conveyor_events(events)
                else:
                    o = self.active_order()
                    if o and o.get("kind") == "total":
                        self.dup = None
                        self._track_batch(summary, now, dt)
                        if o["status"] == "open" and not self.signin_needed():
                            self._running_total(summary, now)
                    else:
                        self._check_dup(blobs, now)
                        self._track_batch(summary, now, dt)
                        self._auto_capture(summary, now)
                self.cond.notify_all()


app = Flask(__name__, static_folder=None)
eng: Engine = None
teach = None          # active teaching session
teach_lock = threading.Lock()


def err(msg, code=400):
    return jsonify(error=msg), code


@app.get("/")
def index():
    return send_from_directory(BASE / "static", "index.html")


def mjpeg(get_img):
    def gen():
        last = -1
        while True:
            with eng.cond:
                eng.cond.wait_for(lambda: eng.frame_id != last, timeout=2.0)
                last = eng.frame_id
                img = get_img()
            if img is None:
                continue
            ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 78])
            if ok:
                b = buf.tobytes()
                yield (b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                       + str(len(b)).encode() + b"\r\n\r\n" + b + b"\r\n")
    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame",
                    headers={"Cache-Control": "no-store"})


@app.get("/static/<name>")
def static_file(name):
    if name not in ("qrcode.js",):
        return err("Not found.", 404)
    return send_from_directory(BASE / "static", name, max_age=86400)


@app.get("/stream.mjpg")
def stream():
    view = request.args.get("view", "annotated")
    return mjpeg(lambda: eng.views.get(view))


@app.get("/api/state")
def state():
    with eng.cond:
        s = copy.deepcopy(eng.summary)
        out = {
            **s,
            "profile": eng.profiles.get("active"),
            "target": eng.settings["target"],
            "roi": eng.settings["roi"],
            "fps": round(eng.fps, 1),
            "camera": {"kind": eng.cam.kind, "md": eng.cam.last_md, "has_af": eng.cam.has_af,
                       "note": eng.cam.error if eng.cam.kind != "picamera2" else ""},
            "capture": {"state": eng.cap_state, "id": eng.capture_id, "last": eng.last_capture,
                        "mode": eng.settings["auto_capture"], "batches_today": eng.batches_today,
                        "arming": eng.cap_since is not None,
                        "hold": eng.settings["capture_hold"]},
            "teaching": teach is not None,
            "order": eng.active_order(),
            "has_pin": bool(eng.eng_pin),
            "dup": eng.dup,
            "station_mode": eng.settings.get("station_mode", "board"),
            "operator": eng.current_operator(),
            "operator_since": eng.operators.get("since"),
            "signin_needed": eng.signin_needed(),
            "has_operators": bool(eng.operators["items"]),
            "error": eng.error,
        }
    return jsonify(out)


@app.get("/api/settings")
def get_settings():
    with eng.cond:
        return jsonify(settings=eng.settings, camera=eng.camera_cfg)


@app.post("/api/settings")
def set_settings():
    d = request.get_json(force=True) or {}
    try:
        upd = coerce({k: v for k, v in d.items() if k != "roi"}, SETTING_TYPES)
    except (TypeError, ValueError) as e:
        return err(f"Invalid value: {e}")
    if upd.get("threshold_mode") not in (None, "fixed", "otsu"):
        return err("threshold_mode must be fixed or otsu")
    if upd.get("auto_capture") not in (None, "off", "lock", "target"):
        return err("auto_capture must be off, lock or target")
    upd = {k: v for k, v in upd.items() if v is not None}
    if "roi" in d:
        r = d["roi"]
        if r is None:
            upd["roi"] = None
        else:
            try:
                r = [float(v) for v in r][:4]
                assert len(r) == 4 and r[2] > 0.02 and r[3] > 0.02
            except Exception:
                return err("roi must be [x, y, w, h] in 0-1 view fractions")
            upd["roi"] = r
    with eng.cond:
        eng.settings.update(upd)
        eng.persist_settings()
        eng.reset_stability()
        return jsonify(settings=eng.settings)


@app.post("/api/camera")
def set_camera():
    d = request.get_json(force=True) or {}
    try:
        upd = coerce(d, CAMERA_TYPES)
    except (TypeError, ValueError) as e:
        return err(f"Invalid value: {e}")
    with eng.cond:
        for k, v in upd.items():
            if v is None and k != "focus":
                continue
            eng.camera_cfg[k] = v
        cfg = dict(eng.camera_cfg)
    try:
        eng.cam.apply(cfg)
    except Exception as e:
        return err(f"Camera rejected the settings: {e}")
    with eng.cond:
        eng.persist_settings()
        eng.reset_stability()
    return jsonify(camera=cfg)


@app.post("/api/camera/lock")
def lock_camera():
    md = eng.cam.last_md or {}
    if not md.get("exposure_us"):
        return err("Exposure lock needs the Raspberry Pi camera.")
    with eng.cond:
        eng.camera_cfg.update(auto_exposure=False, exposure_us=int(md["exposure_us"]),
                              gain=max(1.0, float(md.get("gain") or 1.0)))
        if eng.cam.has_af and md.get("lens") is not None:
            eng.camera_cfg["focus"] = float(md["lens"])
        cfg = dict(eng.camera_cfg)
    eng.cam.apply(cfg)
    with eng.cond:
        eng.persist_settings()
    return jsonify(camera=cfg)


# ---------------------------------------------------------------- capture
@app.post("/api/capture")
def capture_now():
    d = request.get_json(silent=True) or {}
    with eng.cond:
        if eng.signin_needed():
            return err("Sign in first.", 403)
        if eng.settings.get("station_mode") == "conveyor":
            if eng.conv.count == 0:
                return err("Nothing has passed the line since the last log.")
            row = eng.capture("conveyor-manual", d.get("note", ""), override=eng.conveyor_override())
            eng.conv.reset_count()
            return jsonify(ok=True, row=row) if row else err("No frame yet.")
        o = eng.active_order()
        if o and o.get("kind") == "total" and eng.settings.get("station_mode") != "conveyor":
            return err("This order counts by itself: parts on the board are already in the total. "
                       "Bag them and clear the board to keep going.", 409)
        if eng.dup:
            return err("These are the same parts as the last capture. Clear the board first." if eng.dup["kind"] == "same"
                       else f"{eng.dup['n']} parts from the last capture are still on the board. Clear the board first.", 409)
        row = eng.capture("manual", d.get("note", ""))
    if not row:
        return err("No frame yet.")
    return jsonify(ok=True, row=row)


@app.post("/api/conveyor/reset")
def conveyor_reset():
    with eng.cond:
        eng.conv.reset_count()
        if (request.get_json(silent=True) or {}).get("all"):
            eng.conv.reset_all()
    return jsonify(ok=True)


@app.post("/api/capture/rearm")
def rearm():
    with eng.cond:
        eng.cap_state, eng.cap_since, eng.clear_since = "ready", None, None
        eng.confirms = []
        eng.reset_stability()
    return jsonify(ok=True)


@app.get("/api/log")
def recent_log():
    if not LOG_F.exists():
        return jsonify(rows=[])
    with open(LOG_F, newline="") as f:
        rows = list(csv.DictReader(f))
    return jsonify(rows=rows[-30:][::-1])


@app.post("/api/log/delete")
def delete_log_row():
    """Delete one logged capture (and its photo)."""
    d = request.get_json(force=True) or {}
    key_id, key_ts = str(d.get("capture_id") or ""), str(d.get("timestamp") or "")
    if not LOG_F.exists():
        return err("Nothing logged.", 404)
    with eng.cond:
        with open(LOG_F, newline="") as f:
            rows = list(csv.DictReader(f))
        keep, gone = [], []
        for r in rows:
            hit = (key_id and r.get("capture_id") == key_id and r.get("timestamp") == key_ts) or \
                  (not key_id and r.get("timestamp") == key_ts)
            (gone if hit and not gone else keep).append(r)
        if not gone:
            return err("That capture wasn't found.", 404)
        with open(LOG_F, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=LOG_HEADER, extrasaction="ignore")
            w.writeheader()
            w.writerows(keep)
        for r in gone:
            if r.get("photo"):
                try:
                    (CAPTURES / r["photo"]).unlink()
                except OSError:
                    pass
    return jsonify(ok=True)


@app.post("/api/data/reset")
def reset_data():
    """Wipe trial data. what: any of log, orders, parts, people."""
    what = set((request.get_json(force=True) or {}).get("what") or [])
    with eng.cond:
        if "log" in what:
            for p in [LOG_F, *DATA.glob("count_log_old_*.csv")]:
                try:
                    p.unlink()
                except OSError:
                    pass
            for p in CAPTURES.glob("*.jpg"):
                try:
                    p.unlink()
                except OSError:
                    pass
            eng.batches_today, eng.last_capture, eng.last_fp, eng.dup = 0, None, None, None
            eng.cap_state = "ready"
            eng.conv.reset_all()
        if "orders" in what:
            eng.orders = {"active": None, "items": []}
            eng.persist_orders()
        if "parts" in what:
            eng.profiles = {"active": None, "items": {}}
            eng.orders["active"] = None
            eng.persist_orders()
            eng.profiles_changed()
        if "people" in what:
            eng.operators = {"items": [], "current": None, "since": None}
            eng.persist_operators()
    return jsonify(ok=True, cleared=sorted(what))


@app.get("/api/log.csv")
def download_log():
    if not LOG_F.exists():
        return err("Nothing logged yet.", 404)
    return send_file(LOG_F, mimetype="text/csv", as_attachment=True, download_name="count_log.csv")


@app.get("/api/report")
def download_report():
    """Zip with report.html (accuracy, orders, operators, photos), captures.csv and photos/."""
    q = request.args
    day_from, day_to = q.get("from") or None, q.get("to") or None
    with eng.cond:
        orders = copy.deepcopy(eng.orders["items"])
    order_name = None
    if q.get("order"):
        o = next((o for o in orders if o["id"] == q["order"]), None)
        if not o:
            return err("No such order.", 404)
        order_name = o["name"]
    rows = []
    if LOG_F.exists():
        with open(LOG_F, newline="") as f:
            rows = list(csv.DictReader(f))
    rows = report.filter_rows(rows, day_from, day_to, order_name)
    if not rows:
        return err("Nothing was captured in that range.", 404)
    if order_name:
        title, fname = f"Order report: {order_name}", f"order_{order_name}"
    else:
        span = day_from if day_from == day_to else f"{day_from or 'start'} to {day_to or 'today'}"
        title, fname = f"Counting report: {span}", f"report_{day_from or 'all'}_{day_to or 'now'}"
    fname = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in fname) + ".zip"
    data = report.build(rows, orders, socket.gethostname(), app_version(), title, CAPTURES,
                        include_photos=q.get("photos", "1") != "0")
    return Response(data, mimetype="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="{fname}"'})


@app.get("/api/snapshot.jpg")
def snapshot():
    with eng.cond:
        frame = None if eng.frame is None else eng.frame.copy()
    if frame is None:
        return err("No frame yet.", 503)
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 93])
    name = f"board_{datetime.datetime.now():%Y%m%d_%H%M%S}.jpg"
    return Response(buf.tobytes(), mimetype="image/jpeg",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@app.get("/api/captures/<path:name>")
def capture_photo(name):
    if "/" in name or ".." in name or not name.endswith(".jpg"):
        return err("Bad name.", 404)
    p = CAPTURES / name
    if not p.exists():
        return err("Photo not found (older photos are removed to save space).", 404)
    return send_file(p, mimetype="image/jpeg")


# ---------------------------------------------------------------- orders
def _activate_order(o):
    """Call with eng.cond held. Returns camera cfg to apply."""
    eng.orders["active"] = o["id"] if o else None
    eng.rt_prev, eng.rt_since, eng.cap_state = None, None, "ready"
    eng.persist_orders()
    if not o:
        eng.cap_state = "ready"
        return None
    cfg = eng.select_part(o["part"])
    eng.settings["target"] = o["per_batch"] if o.get("kind") != "total" else 0
    eng.persist_settings()
    return cfg


@app.get("/api/orders")
def list_orders():
    with eng.cond:
        items = sorted(eng.orders["items"], key=lambda o: (o["status"] != "open", o.get("created", "")), reverse=False)
        open_ = [o for o in items if o["status"] == "open"][::-1]
        done = [o for o in items if o["status"] != "open"][::-1][:20]
        return jsonify(active=eng.orders.get("active"), open=open_, done=done)


@app.post("/api/orders")
def create_order():
    d = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()[:60]
    part = d.get("part")
    kind = "total" if d.get("kind") == "total" else "kits"
    try:
        per = int(d.get("per_batch") or 0)
        batches = int(d.get("batches") or 0)
        total = int(d.get("total") or 0)
    except ValueError:
        return err("Quantities must be whole numbers.")
    if not name:
        return err("Give the order a name or work order number.")
    if kind == "total" and total < 1:
        return err("How many parts are needed in total?")
    if kind == "kits" and per < 1:
        return err("How many parts go in each kit or bag?")
    if batches < 0:
        return err("Number of kits can't be negative.")
    with eng.cond:
        if part not in eng.profiles["items"]:
            return err("Pick a part that has been taught.")
        o = {"id": f"o{int(time.time() * 1000)}", "name": name, "part": part, "kind": kind,
             "per_batch": per if kind == "kits" else 0, "batches": batches if kind == "kits" else 0,
             "total": total if kind == "total" else per * batches, "done": 0, "done_parts": 0, "status": "open",
             "created": datetime.datetime.now().isoformat(timespec="seconds")}
        eng.orders["items"].append(o)
        eng.orders["items"] = eng.orders["items"][-500:]
        cfg = _activate_order(o)
    if cfg:
        try:
            eng.cam.apply(cfg)
        except Exception:
            pass
    return jsonify(order=o)


@app.post("/api/orders/activate")
def activate_order():
    oid = (request.get_json(force=True) or {}).get("id")
    with eng.cond:
        o = next((o for o in eng.orders["items"] if o["id"] == oid), None) if oid else None
        if oid and not o:
            return err("No such order.", 404)
        if o and o["part"] not in eng.profiles["items"]:
            return err(f"The part {o['part']} for this order has been deleted. Teach it again first.")
        if o and o["status"] != "open":
            o["status"] = "open"           # reopening a finished order
        cfg = _activate_order(o)
    if cfg:
        try:
            eng.cam.apply(cfg)
        except Exception:
            pass
    return jsonify(ok=True)


@app.post("/api/orders/update")
def update_order():
    d = request.get_json(force=True) or {}
    with eng.cond:
        o = next((o for o in eng.orders["items"] if o["id"] == d.get("id")), None)
        if not o:
            return err("No such order.", 404)
        if d.get("delete"):
            eng.orders["items"].remove(o)
            if eng.orders.get("active") == o["id"]:
                eng.orders["active"] = None
        elif d.get("close"):
            o["status"] = "closed"
            if eng.orders.get("active") == o["id"]:
                eng.orders["active"] = None
        else:
            if "done" in d:
                o["done"] = max(0, int(d["done"]))
            if "batches" in d:
                o["batches"] = max(0, int(d["batches"]))
            if "done_parts" in d:
                o["done_parts"] = max(0, int(d["done_parts"]))
            if "total" in d and o.get("kind") == "total":
                o["total"] = max(1, int(d["total"]))
            finished = (o["done_parts"] >= o["total"]) if o.get("kind") == "total" else (o["batches"] and o["done"] >= o["batches"])
            if finished:
                o["status"] = "complete"
            elif o["status"] == "complete":
                o["status"] = "open"
        eng.persist_orders()
        return jsonify(order=o)


# ---------------------------------------------------------------- operators
@app.get("/api/operators")
def list_operators():
    with eng.cond:
        return jsonify(items=sorted(eng.operators["items"], key=lambda o: o["name"].lower()),
                       current=eng.operators.get("current"))


@app.post("/api/operators")
def add_operator():
    d = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()[:40]
    badge = (d.get("badge") or "").strip()[:80]
    if not name:
        return err("Type the person's name.")
    with eng.cond:
        if any(o["name"].lower() == name.lower() for o in eng.operators["items"]):
            return err(f"{name} is already on the list.")
        if badge and any(o.get("badge") == badge for o in eng.operators["items"]):
            return err("That badge code belongs to someone else.")
        o = {"id": f"p{int(time.time() * 1000)}", "name": name, "badge": badge}
        eng.operators["items"].append(o)
        eng.persist_operators()
    return jsonify(operator=o)


@app.post("/api/operators/update")
def update_operator():
    d = request.get_json(force=True) or {}
    with eng.cond:
        o = next((o for o in eng.operators["items"] if o["id"] == d.get("id")), None)
        if not o:
            return err("No such person.", 404)
        if d.get("delete"):
            eng.operators["items"].remove(o)
            if eng.operators.get("current") == o["id"]:
                eng.operators["current"] = None
        elif "badge" in d:
            badge = (d.get("badge") or "").strip()[:80]
            if badge and any(x.get("badge") == badge and x is not o for x in eng.operators["items"]):
                return err("That badge code belongs to someone else.")
            o["badge"] = badge
        eng.persist_operators()
    return jsonify(ok=True)


@app.post("/api/signin")
def signin():
    d = request.get_json(force=True) or {}
    with eng.cond:
        items = eng.operators["items"]
        if d.get("badge"):
            code = str(d["badge"]).strip()
            o = next((o for o in items if o.get("badge") and o["badge"] == code), None)
            if not o:
                return err("Badge not recognized. Tap your name instead, or ask an engineer to add your badge.", 404)
        else:
            o = next((o for o in items if o["id"] == d.get("id")), None)
            if not o:
                return err("Pick your name.", 404)
        eng.operators["current"] = o["id"]
        eng.operators["since"] = datetime.datetime.now().isoformat(timespec="minutes")
        eng.persist_operators()
    return jsonify(operator=o)


@app.post("/api/signout")
def signout():
    with eng.cond:
        eng.operators["current"] = None
        eng.operators["since"] = None
        eng.persist_operators()
    return jsonify(ok=True)


# ---------------------------------------------------------------- power
@app.post("/api/system/power")
def system_power():
    """Shut down or restart the Pi. Needs the sudo rule that get.sh / install.sh add."""
    import subprocess
    action = (request.get_json(force=True) or {}).get("action")
    if action not in ("shutdown", "reboot"):
        return err("Unknown action.")
    cmd = ["sudo", "-n", "/usr/bin/systemctl", "poweroff" if action == "shutdown" else "reboot"]
    try:
        # check permission first without doing anything
        chk = subprocess.run(["sudo", "-n", "-l", cmd[2], cmd[3]], capture_output=True, timeout=5)
    except Exception as e:
        return err(f"Can't do that on this computer: {e}")
    if chk.returncode != 0:
        return err("The counter isn't allowed to do this yet. Run the install line from your /counter/ "
                   "page on the Pi once more, then try again.", 403)
    threading.Timer(1.5, lambda: subprocess.Popen(cmd)).start()
    return jsonify(ok=True)


# ---------------------------------------------------------------- engineering lock
@app.post("/api/eng/unlock")
def eng_unlock():
    pin = str((request.get_json(force=True) or {}).get("pin", ""))
    if eng.eng_pin and pin != eng.eng_pin:
        return err("Wrong PIN.", 403)
    return jsonify(ok=True)


@app.post("/api/eng/pin")
def eng_set_pin():
    d = request.get_json(force=True) or {}
    if eng.eng_pin and str(d.get("old", "")) != eng.eng_pin:
        return err("Current PIN is wrong.", 403)
    new = str(d.get("pin", "")).strip()
    if new and (not new.isdigit() or not 4 <= len(new) <= 8):
        return err("PIN must be 4 to 8 digits, or empty for no PIN.")
    with eng.cond:
        eng.eng_pin = new
        eng.persist_settings()
    return jsonify(ok=True, has_pin=bool(new))


# ---------------------------------------------------------------- profiles
def profile_summary(p):
    return {"name": p["name"], "updated": p.get("updated"), "ignores": len(p.get("ignores", [])),
            "views": [{"id": v["id"], "tag": v.get("tag"), "name": v["name"], "color": v.get("color"),
                       "n": len(v.get("samples", [])), "unit": round(v["unit_area"])} for v in p["views"]]}


@app.get("/api/profiles")
def list_profiles():
    with eng.cond:
        items = [profile_summary(p) for p in eng.profiles["items"].values()]
        return jsonify(active=eng.profiles.get("active"), items=sorted(items, key=lambda p: p["name"].lower()))


@app.post("/api/profiles/select")
def select_profile():
    name = (request.get_json(force=True) or {}).get("name")
    with eng.cond:
        try:
            cfg = eng.select_part(name)
        except KeyError:
            return err(f"No part named {name}.", 404)
        o = eng.active_order()
        if o and o["part"] != name:
            eng.orders["active"] = None          # switching part leaves the order
            eng.persist_orders()
    try:
        eng.cam.apply(cfg)
    except Exception:
        pass
    return jsonify(ok=True)


@app.post("/api/profiles/delete")
def delete_profile():
    name = (request.get_json(force=True) or {}).get("name")
    with eng.cond:
        if name not in eng.profiles["items"]:
            return err(f"No part named {name}.", 404)
        del eng.profiles["items"][name]
        if eng.profiles.get("active") == name:
            eng.profiles["active"] = None
        o = eng.active_order()
        if o and o["part"] == name:
            eng.orders["active"] = None
            eng.persist_orders()
        eng.profiles_changed()
    return jsonify(ok=True)


@app.post("/api/profiles/view")
def edit_view():
    """Rename or delete a view of a saved part."""
    d = request.get_json(force=True) or {}
    with eng.cond:
        p = eng.profiles["items"].get(d.get("part"))
        if not p:
            return err("No such part.", 404)
        v = next((v for v in p["views"] if v["id"] == d.get("id")), None)
        if not v:
            return err("No such view.", 404)
        if d.get("delete"):
            if len(p["views"]) == 1:
                return err("A part needs at least one view. Delete the part instead.")
            p["views"].remove(v)
        elif d.get("name"):
            v["name"] = str(d["name"]).strip()[:40]
        eng.profiles_changed()
        return jsonify(part=profile_summary(p))


# ------------------------------------------------- tap-to-correct (live view)
def _live_blob(d):
    """Find the blob under a tapped point (normalized x, y) in the current frame."""
    with eng.cond:
        blobs = list(eng.blobs)
        W, H = eng.summary.get("frame_size", [1, 1])
    x, y = float(d.get("x", -1)) * W, float(d.get("y", -1)) * H
    i = vision.blob_at(blobs, x, y, max_dist=0.02 * W)
    return (blobs[i] if i is not None else None)


@app.post("/api/blob")
def blob_info():
    b = _live_blob(request.get_json(force=True) or {})
    if not b:
        return jsonify(found=False)
    with eng.cond:
        prof = eng.active_profile()
    unit = None
    if prof and prof["views"]:
        unit = max(prof["views"], key=lambda v: len(v["samples"]))["unit_area"]
    return jsonify(found=True, kind=b["kind"], area=round(b["area"]), view=b.get("view"), est=b.get("est"),
                   edge=b["edge"], size_vs_part=round(b["area"] / unit, 2) if unit else None)


@app.post("/api/blob/confirm")
def blob_confirm():
    """Operator says how many parts a flagged group really is (n=0 undoes it)."""
    d = request.get_json(force=True) or {}
    b = _live_blob(d)
    if not b:
        return err("Nothing found where you tapped. Tap right on the group.")
    try:
        n = int(d.get("n", 0))
    except ValueError:
        return err("Count must be a whole number.")
    if not 0 <= n <= 500:
        return err("Count must be between 0 and 500.")
    with eng.cond:
        if not eng.active_profile():
            return err("Select a part first.")
        i = vision.match_confirm(b, eng.confirms)
        if i is not None:
            eng.confirms.pop(i)
        if n > 0:
            if b["kind"] not in ("clump", "foreign", "partial", "confirmed"):
                return err("That one is already counted. Only flagged items need confirming.")
            cx, cy = vision.blob_center(b)
            eng.confirms.append({"x": cx, "y": cy, "area": b["area"], "n": n})
        eng.reset_stability()
    if n == 0:
        return jsonify(ok=True, message="Confirmation removed.")
    return jsonify(ok=True, message=f"Counting that group as {n}. If it gets moved, it will ask again.")


@app.post("/api/blob/label")
def blob_label():
    d = request.get_json(force=True) or {}
    b = _live_blob(d)
    if not b:
        return err("Nothing found where you tapped. Tap right on the part.")
    action = d.get("action")
    with eng.cond:
        p = eng.active_profile()
        if not p:
            return err("Select a part first.")
        c = vision.normalize_contour(b["c"])
        if action == "ignore":
            p.setdefault("ignores", []).append({"area": b["area"], "ref": c.reshape(-1, 2).tolist(), "feat": b["feat"]})
            msg = f"Things shaped like this will be ignored for {p['name']}."
        elif action == "new_view":
            name = (d.get("name") or "").strip()[:40] or f"View {chr(65 + len(p['views']))}"
            used = {v.get("tag") for v in p["views"]}
            tag = next(ch for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if ch not in used)
            vid = f"v{int(time.time() * 1000) % 10**9}"
            st = vision.view_stats([b["area"]], [(b["c"], b["feat"])])
            p["views"].append({"id": vid, "tag": tag, "name": name,
                               "color": vision.VIEW_COLORS[len(p["views"]) % len(vision.VIEW_COLORS)], **st})
            msg = f"Added a new view “{name}” to {p['name']}. Tap a few more like it to strengthen it."
        elif action == "view":
            v = next((v for v in p["views"] if v["id"] == d.get("view_id")), None)
            if not v:
                return err("Pick a view.")
            r = b["area"] / v["unit_area"]
            if not 0.55 <= r <= 1.7 and not d.get("force"):
                return err(f"That item is {r:.1f}× the size of “{v['name']}”. If it's one part landing a "
                           "different way, add it as a new view instead. If it's several parts touching, "
                           "spread them apart.", 409)
            refs, feats = v.get("refs", []), v.get("ref_feats", [])
            k = len(refs) if len(refs) < 6 else 5
            st = vision.view_stats(v["samples"] + [b["area"]], [(b["c"], b["feat"])],
                                   base_refs=refs[:k], base_feats=feats[:k])
            st["shape_thresh"] = max(st["shape_thresh"], float(v.get("shape_thresh", 0.15)))
            v.update(st)
            msg = f"Added to “{v['name']}”."
        else:
            return err("Unknown action.")
        p["updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
        eng.profiles_changed()
        return jsonify(ok=True, message=msg, part=profile_summary(p))


# ------------------------------------------------------------ teach wizard
def _teach_state():
    t = teach
    views = []
    for v in t["views"]:
        n = sum(1 for r in t["rounds"] for lab in r["labels"] if lab["t"] == "view" and lab["id"] == v["id"])
        views.append({"id": v["id"], "tag": v["tag"], "name": v["name"], "color": v["color"],
                      "new_samples": n, "saved_samples": len(v.get("base", {}).get("samples", []))})
    rounds = []
    for i, r in enumerate(t["rounds"]):
        c = collections.Counter()
        for lab in r["labels"]:
            c[lab["id"] if lab["t"] == "view" else lab["t"]] += 1
        rounds.append({"i": i, "counts": dict(c), "total": len(r["labels"]), "v": r["v"]})
    return {"name": t["name"], "existing": t["existing"], "views": views, "rounds": rounds}


def _teach_models():
    """Current statistics of every teaching view (for auto-sorting new blobs)."""
    models = []
    for v in teach["views"]:
        areas = list(v.get("base", {}).get("samples", []))
        cont = []
        for r in teach["rounds"]:
            for b, lab in zip(r["blobs"], r["labels"]):
                if lab["t"] == "view" and lab["id"] == v["id"]:
                    areas.append(b["area"])
                    cont.append((b["c"], b["feat"]))
        if not areas:
            continue
        unit = float(sorted(areas)[len(areas) // 2])
        base = v.get("base", {})
        refs = [vision.to_contour(x) for x in base.get("refs", [])][:3]
        feats = [list(f) for f in base.get("ref_feats", [])][:len(refs)]
        for c, f in sorted(cont, key=lambda cf: abs(cv2.contourArea(cf[0]) - unit))[:3]:
            refs.append(vision.normalize_contour(c))
            feats.append(f)
        models.append({"id": v["id"], "unit": unit, "sigs": [vision.hu_sig(r) for r in refs],
                       "feats": feats, "thresh": base.get("shape_thresh", 0.4)})
    return models


def _new_teach_view(name=None):
    used = {v["tag"] for v in teach["views"]}
    tag = next(ch for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if ch not in used)
    v = {"id": f"t{len(teach['views'])}_{int(time.time() * 1000) % 10**6}", "tag": tag,
         "name": name or f"View {tag}",
         "color": vision.VIEW_COLORS[len(teach["views"]) % len(vision.VIEW_COLORS)]}
    teach["views"].append(v)
    return v


@app.get("/api/teach")
def teach_get():
    with teach_lock:
        if not teach:
            return jsonify(active=False)
        return jsonify(active=True, **_teach_state())


@app.post("/api/teach/start")
def teach_start():
    global teach
    name = ((request.get_json(force=True) or {}).get("name") or "").strip()[:60]
    if not name:
        return err("Give the part a name first.")
    with eng.cond:
        existing = copy.deepcopy(eng.profiles["items"].get(name))
    with teach_lock:
        teach = {"name": name, "existing": bool(existing), "views": [], "rounds": [],
                 "ignores": list(existing.get("ignores", [])) if existing else []}
        if existing:
            for v in existing["views"]:
                teach["views"].append({"id": v["id"], "tag": v.get("tag", "?"), "name": v["name"],
                                       "color": v.get("color", vision.VIEW_COLORS[0]), "base": v})
        return jsonify(active=True, **_teach_state())


@app.post("/api/teach/capture")
def teach_capture():
    with eng.cond:
        if eng.frame is None:
            return err("No camera frame yet.")
        frame = eng.frame.copy()
        blobs = [{"c": b["c"], "area": b["area"], "edge": b["edge"], "feat": b["feat"], "sig": b["sig"]} for b in eng.blobs]
        sw = eng.settings["stream_width"]
    with teach_lock:
        if not teach:
            return err("Start teaching first.")
        if not blobs:
            return err("Nothing found on the board. Check the count area and that Mask view shows the parts in white.")
        models = _teach_models()
        known = {m["id"] for m in models}
        labels = [None] * len(blobs)
        created = []
        for i in sorted(range(len(blobs)), key=lambda i: blobs[i]["area"]):
            b = blobs[i]
            if b["edge"]:
                labels[i] = {"t": "skip", "why": "edge"}
                continue
            m = vision.match_teach_view(b["sig"], b["feat"], b["area"], models)
            if not m:
                m = {"id": f"new{len(created)}", "unit": b["area"], "sigs": [b["sig"]],
                     "feats": [b["feat"]], "thresh": 0.4}
                models.append(m)
                created.append(m)
            labels[i] = {"t": "view", "id": m["id"]}
        # Groups seen only once or twice are usually touching parts or junk, not a new
        # way of landing: skip them if they're much bigger/smaller than an established view.
        sizes = collections.Counter(l["id"] for l in labels if l["t"] == "view")
        solid = [m for m in models if m["id"] in known or sizes[m["id"]] >= 3]
        for m in created:
            if sizes[m["id"]] >= 3 or not solid:
                continue
            others = [o for o in solid if o is not m]
            biggest = max(o["unit"] for o in others) if others else 0
            why = None
            if biggest and m["unit"] >= 1.7 * biggest:
                why = "touching?"
            elif sizes[m["id"]] == 1 and others and all(m["unit"] < 0.25 * o["unit"] for o in others):
                why = "too small?"
            elif sizes[m["id"]] == 1 and others:
                why = "odd one?"
            if why:
                for j, l in enumerate(labels):
                    if l["t"] == "view" and l["id"] == m["id"]:
                        labels[j] = {"t": "skip", "why": why}
        for m in created:   # whatever is left becomes a real teaching view
            if any(l["t"] == "view" and l["id"] == m["id"] for l in labels):
                v = _new_teach_view()
                for l in labels:
                    if l["t"] == "view" and l["id"] == m["id"]:
                        l["id"] = v["id"]
        small, sc = vision.fit_width(frame, sw)
        teach["rounds"].append({"small": small, "scale": sc, "size": frame.shape[1::-1],
                                "blobs": blobs, "labels": labels, "v": 0})
        return jsonify(round=len(teach["rounds"]) - 1, **_teach_state())


@app.get("/api/teach/round/<int:i>.jpg")
def teach_round_img(i):
    with teach_lock:
        if not teach or not 0 <= i < len(teach["rounds"]):
            return err("No such round.", 404)
        r = teach["rounds"][i]
        img = vision.draw_teach(r["small"], r["scale"], r["blobs"], r["labels"],
                                {v["id"]: v for v in teach["views"]})
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return Response(buf.tobytes(), mimetype="image/jpeg", headers={"Cache-Control": "no-store"})


@app.post("/api/teach/label")
def teach_label():
    """Relabel blobs in a captured round: tap one (x, y) or drag a box (rect)."""
    d = request.get_json(force=True) or {}
    with teach_lock:
        if not teach:
            return err("Start teaching first.")
        try:
            r = teach["rounds"][int(d["round"])]
        except (KeyError, IndexError, ValueError):
            return err("No such round.")
        W, H = r["size"]
        if d.get("rect"):
            x0, y0, x1, y1 = d["rect"]
            idx = vision.blobs_in_rect(r["blobs"], min(x0, x1) * W, min(y0, y1) * H, max(x0, x1) * W, max(y0, y1) * H)
        else:
            i = vision.blob_at(r["blobs"], float(d["x"]) * W, float(d["y"]) * H, 0.02 * W)
            idx = [] if i is None else [i]
        if not idx:
            return err("Nothing there. Tap right on a part, or drag a box around several.")
        lab = d.get("label") or {}
        if lab.get("t") == "new":
            v = _new_teach_view((lab.get("name") or "").strip()[:40] or None)
            new = {"t": "view", "id": v["id"]}
        elif lab.get("t") == "view" and any(v["id"] == lab.get("id") for v in teach["views"]):
            new = {"t": "view", "id": lab["id"]}
        elif lab.get("t") == "ignore":
            new = {"t": "ignore"}
        else:
            new = {"t": "skip", "why": "skipped"}
        for i in idx:
            r["labels"][i] = dict(new)
        r["v"] += 1
        return jsonify(changed=len(idx), **_teach_state())


@app.post("/api/teach/view")
def teach_view():
    d = request.get_json(force=True) or {}
    with teach_lock:
        if not teach:
            return err("Start teaching first.")
        v = next((v for v in teach["views"] if v["id"] == d.get("id")), None)
        if not v:
            return err("No such view.")
        if d.get("delete"):
            teach["views"].remove(v)
            for r in teach["rounds"]:
                for j, lab in enumerate(r["labels"]):
                    if lab["t"] == "view" and lab["id"] == v["id"]:
                        r["labels"][j] = {"t": "skip", "why": "skipped"}
                r["v"] += 1
        elif d.get("name"):
            v["name"] = str(d["name"]).strip()[:40]
        return jsonify(**_teach_state())


@app.post("/api/teach/discard")
def teach_discard():
    i = int((request.get_json(force=True) or {}).get("round", -1))
    with teach_lock:
        if teach and 0 <= i < len(teach["rounds"]):
            teach["rounds"].pop(i)
            used = {lab["id"] for r in teach["rounds"] for lab in r["labels"] if lab["t"] == "view"}
            teach["views"] = [v for v in teach["views"] if v.get("base") or v["id"] in used]
        return jsonify(**_teach_state()) if teach else jsonify(active=False)


@app.post("/api/teach/cancel")
def teach_cancel():
    global teach
    with teach_lock:
        teach = None
    return jsonify(ok=True)


@app.post("/api/teach/save")
def teach_save():
    global teach
    with teach_lock:
        if not teach:
            return err("Start teaching first.")
        views_out, warnings = [], []
        ignores = list(teach["ignores"])
        for r in teach["rounds"]:
            for b, lab in zip(r["blobs"], r["labels"]):
                if lab["t"] == "ignore":
                    ignores.append({"area": b["area"], "feat": b["feat"],
                                    "ref": vision.normalize_contour(b["c"]).reshape(-1, 2).tolist()})
        for v in teach["views"]:
            base = v.get("base") or {}
            areas, cont = list(base.get("samples", [])), []
            for r in teach["rounds"]:
                for b, lab in zip(r["blobs"], r["labels"]):
                    if lab["t"] == "view" and lab["id"] == v["id"]:
                        areas.append(b["area"])
                        cont.append((b["c"], b["feat"]))
            if not areas:
                continue
            new_n = len(cont)
            if not base and new_n < 3:
                warnings.append(f"“{v['name']}” has only {new_n} sample{'s' if new_n != 1 else ''}. "
                                "Tap a few more like it in the live view to strengthen it.")
            st = vision.view_stats(areas, cont, base_refs=base.get("refs", [])[:3],
                                   base_feats=base.get("ref_feats", [])[:3])
            if base:
                st["shape_thresh"] = max(st["shape_thresh"], float(base.get("shape_thresh", 0.15)))
            views_out.append({"id": v["id"], "tag": v["tag"], "name": v["name"], "color": v["color"], **st})
        if not views_out:
            return err("No parts are assigned to a view yet. Capture a round first.")
        with eng.cond:
            s = dict(eng.settings)
            old = eng.profiles["items"].get(teach["name"])
            now = time.strftime("%Y-%m-%d %H:%M:%S")
            if old and old.get("seg") and any(old["seg"].get(k) != s.get(k) for k in vision.SEG_KEYS):
                warnings.append("Detection settings differ from when this part was first taught, so older "
                                "samples may not match perfectly. If counts look off, delete the part and teach it fresh.")
            prof = {"name": teach["name"], "views": views_out, "ignores": ignores[-50:],
                    "seg": {k: s[k] for k in vision.SEG_KEYS}, "roi": s.get("roi"),
                    "camera": dict(eng.camera_cfg),
                    "created": old.get("created", now) if old else now, "updated": now}
            eng.profiles["items"][teach["name"]] = prof
            eng.profiles["active"] = teach["name"]
            o = eng.active_order()
            if o and o["part"] != teach["name"]:
                eng.orders["active"] = None
                eng.persist_orders()
            eng.cap_state = "ready"
            eng.profiles_changed()
            summary = profile_summary(prof)
        teach = None
    return jsonify(ok=True, part=summary, warnings=warnings)


# ---------------------------------------------------------------- updates
def update_base():
    try:
        u = UPDATE_URL_F.read_text().strip()
    except OSError:
        u = ""
    return (u.rstrip("/") + "/") if u else ""


def fetch(url, limit=20_000_000):
    req = urllib.request.Request(url, headers={"User-Agent": "partcounter", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("download too large")
    return data


@app.get("/api/version")
def version_info():
    return jsonify(version=app_version(), update_url=update_base())


@app.post("/api/update/url")
def set_update_url():
    u = ((request.get_json(force=True) or {}).get("url") or "").strip()
    if u and not u.startswith(("https://", "http://")):
        return err("The address must start with https://")
    UPDATE_URL_F.write_text(u)
    return jsonify(update_url=update_base())


@app.post("/api/update/check")
def update_check():
    base = update_base()
    if not base:
        return err("Set the update address first (your GitHub Pages partcounter/ link).")
    try:
        latest = fetch(base + "version.txt", 1000).decode().strip()
    except Exception as e:
        return err(f"Couldn't reach {base}: {e}. Check the Pi has internet.")
    return jsonify(current=app_version(), latest=latest, newer=latest != app_version())


@app.post("/api/update")
def update_now():
    base = update_base()
    if not base:
        return err("Set the update address first.")
    try:
        z = zipfile.ZipFile(io.BytesIO(fetch(base + "partcounter.zip")))
        names = z.namelist()
        if "partcounter/app.py" not in names or "partcounter/static/index.html" not in names:
            return err("That download doesn't look like Part Counter.")
        tmp = Path(tempfile.mkdtemp())
        z.extractall(tmp)
        src = tmp / "partcounter"
        for p in src.rglob("*"):
            rel = p.relative_to(src)
            if rel.parts and rel.parts[0] == "data":
                continue                       # never touch saved parts, settings or the log
            dst = BASE / rel
            if p.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dst)
        shutil.rmtree(tmp, ignore_errors=True)
        new = (BASE / "VERSION").read_text().strip() if (BASE / "VERSION").exists() else "?"
    except Exception as e:
        return err(f"Update failed: {e}")
    # Exit; systemd (Restart=always) starts the new version a few seconds later.
    threading.Timer(1.0, lambda: os._exit(0)).start()
    return jsonify(ok=True, version=new)


def main():
    global eng
    ap = argparse.ArgumentParser(description="Part Counter server")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--source", default="auto", choices=["auto", "picamera", "usb", "demo"])
    ap.add_argument("--width", type=int, default=2304)
    ap.add_argument("--height", type=int, default=1296)
    a = ap.parse_args()

    cam = Camera((a.width, a.height), a.source)
    print(f"[partcounter] version {app_version()}, camera: {cam.kind} {cam.error}")
    eng = Engine(cam)
    host = socket.gethostname()
    print(f"[partcounter] open http://{host}.local:{a.port}  (or http://<pi-ip>:{a.port})")
    app.run(host=a.host, port=a.port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
