# Part Counter

Counts small parts on a backlit light board with a Raspberry Pi 5 + Pi camera.
Runs on the Pi; any computer on the same network opens it in a browser:
`http://<pi-address>:8080`

## Install (first time)
Copy this folder to the Pi, then on the Pi: `cd ~/partcounter && bash install.sh`

## Update (keeps your parts and log)
In the counter: Detection and camera settings > Software > Update now.
Or on the Pi, paste the install line from the Part Counter web page again.

## Screens
- **Operator screen** (everything on one screen): tap the job button to start an
  order (name or scan the work order, pick the part, parts per kit, number of
  kits) or just count a part. The counter captures each full kit by itself,
  ticks it off, and waits for the board to clear. Tap a yellow group to confirm
  how many parts it is.
- **Engineering**: click the shark logo (top left). Parts and teaching, setup
  (count area, detection, camera, auto capture), the log with a photo of every
  capture, and system (PIN lock, software update). All number boxes open a
  keypad; a keyboard or barcode scanner works too.

## Sign-in, labels, reports
- **People** (shark > People): add operators, optionally with a badge code. When
  anyone is on the list, operators must sign in (tap name or scan badge) before
  counting. Every capture records who was signed in.
- **Bag labels** (shark > System): set the label size, tick "this computer has
  the label printer" on the station PC, and optionally auto-print every good
  kit. The 🏷 Label button reprints the last capture; 🏷 in the log reprints any.
  For silent printing, start Chrome/Edge with `--kiosk-printing`.
- **Reports** (shark > Log): today, last 7 days, dates, or one order. Zip with
  report.html (orders, accuracy, operators, capture photos), captures.csv and
  full-size photos.
- **Engineering PIN**: starts as 1064. Change it in shark > System.

## Station setup
1. Set count area: drag a box inside the lit board, away from its frame.
2. Mask view: parts solid white on black. Adjust Threshold until they are.
3. Lock current exposure and focus.

## Teaching a part
Press **Teach a new part**, name it, then follow the four captures:
as they land, flipped over, other sides, shaken. After each capture the
parts are colour-sorted into views (A, B, C...). Tap a part to fix it, or
drag a box to fix several: put it in a view, make a new view, skip it, or
mark it "not a part". Name the views (Flat, On edge...) and press Save.
To add views later, press **Teach more views** on the part.

While counting, tap any outlined item to correct it the same way.

**Touching parts:** tap a yellow `x2?` group and pick how many parts it really
is. It turns green (`x3 ok`), counts, and stops blocking auto capture. That
confirmation is for that group this time only: if the group is moved, or the
board is cleared, it asks again.

## Counting
- Green number + "Count locked" = no flags, steady count.
- **Auto capture** (When count locks / At target) logs the count after it holds
  steady, beeps, then waits for the board to be cleared before the next batch.
- **Capture now** logs any time (testing). **Start next count** re-arms
  without clearing.
- Log: `data/count_log.csv`, or Download CSV on the screen.

| Outline | Meaning |
|---|---|
| Green | counted |
| Yellow `x2?` | touching or stacked, shake or spread |
| Red `?` | wrong shape (remove, or tap to teach) |
| Pink `!` | smaller than the part |
| Blue `edge` | cut off by the count area |
| Grey | specks or taught "not a part", ignored |

Any flag blocks auto capture until it's cleared.

## Files
`app.py` server, `vision.py` detection, `camera.py` camera, `static/index.html`
screen, `data/` your parts, settings and log (back this up).
